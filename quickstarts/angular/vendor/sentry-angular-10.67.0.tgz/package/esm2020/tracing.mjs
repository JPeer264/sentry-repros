import { Directive, Injectable, Input, NgModule } from '@angular/core';
// Duplicated import to work around a TypeScript bug where it'd complain that `Router` isn't imported as a type.
// We need to import it as a value to satisfy Angular dependency injection. So:
// eslint-disable-next-line @typescript-eslint/consistent-type-imports
import { NavigationCancel, NavigationError } from '@angular/router';
import { NavigationEnd, NavigationStart, ResolveEnd } from '@angular/router';
import { browserTracingIntegration as originalBrowserTracingIntegration, getActiveSpan, getClient, getCurrentScope, getRootSpan, SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN, spanToJSON, startBrowserTracingNavigationSpan, startInactiveSpan, getAbsoluteUrl, } from '@sentry/browser';
import { SENTRY_SEGMENT_NAME_SOURCE, CODE_FUNCTION_NAME, SENTRY_OP, URL_FULL, URL_PATH, URL_TEMPLATE, } from '@sentry/conventions/attributes';
import { FUNCTION, ROUTER } from '@sentry/conventions/op';
import { debug, hasSpanStreamingEnabled, NAVIGATION_SPAN_NAME_FALLBACK, parseStringToURLObject, ROUTER_SPAN_NAME_FALLBACK, stripUrlQueryAndFragment, timestampInSeconds, filterCollectedUrl, } from '@sentry/core';
import { Subscription } from 'rxjs';
import { filter, tap } from 'rxjs/operators';
import { UI_MOUNT } from '@sentry/conventions/op';
import { IS_DEBUG_BUILD } from './flags';
import { runOutsideAngular } from './zone';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
let instrumentationInitialized;
/**
 * A custom browser tracing integration for Angular.
 *
 * Use this integration in combination with `TraceService`
 */
export function browserTracingIntegration(options = {}) {
    // If the user opts out to set this up, we just don't initialize this.
    // That way, the TraceService will not actually do anything, functionally disabling this.
    if (options.instrumentNavigation !== false) {
        instrumentationInitialized = true;
    }
    return originalBrowserTracingIntegration({
        ...options,
        instrumentNavigation: false,
    });
}
/**
 * This function is extracted to make unit testing easier.
 */
export function _updateSpanAttributesForParametrizedUrl(route, url, span) {
    if (!span) {
        return;
    }
    const attributes = spanToJSON(span).attributes;
    if (!attributes || attributes[SENTRY_SEGMENT_NAME_SOURCE] === 'url') {
        span.updateName(route);
        const absoluteUrl = getAbsoluteUrl(url);
        span.setAttributes({
            [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: `auto.${attributes[SENTRY_OP]}.angular`,
            [SENTRY_SEGMENT_NAME_SOURCE]: 'route',
            [URL_FULL]: filterCollectedUrl(absoluteUrl),
            [URL_PATH]: parseStringToURLObject(absoluteUrl)?.pathname,
            [URL_TEMPLATE]: route,
        });
    }
}
/**
 * Angular's Service responsible for hooking into Angular Router and tracking current navigation process.
 * Creates a new transaction for every route change and measures a duration of routing process.
 */
export class TraceService {
    constructor(_router) {
        this._router = _router;
        this.navStart$ = this._router.events.pipe(filter((event) => event instanceof NavigationStart), tap(navigationEvent => {
            if (!instrumentationInitialized) {
                IS_DEBUG_BUILD &&
                    debug.error('Angular integration has tracing enabled, but Tracing integration is not configured');
                return;
            }
            if (this._routingSpan) {
                this._routingSpan.end();
                this._routingSpan = null;
            }
            const client = getClient();
            const strippedUrl = stripUrlQueryAndFragment(navigationEvent.url);
            if (client) {
                // see comment in `_isPageloadOngoing` for rationale
                if (!this._isPageloadOngoing()) {
                    runOutsideAngular(() => {
                        startBrowserTracingNavigationSpan(client, {
                            // With span streaming, span names have to be low cardinality. The parameterized route
                            // is only known on `ResolveEnd`, which updates the span name then.
                            name: hasSpanStreamingEnabled(client) ? NAVIGATION_SPAN_NAME_FALLBACK : strippedUrl,
                            attributes: {
                                [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: 'auto.navigation.angular',
                                [SENTRY_SEGMENT_NAME_SOURCE]: 'url',
                            },
                        }, {
                            url: getAbsoluteUrl(navigationEvent.url),
                        });
                    });
                }
                else {
                    // The first time we end up here, we set the pageload flag to false
                    // Subsequent navigations are going to get their own navigation root span
                    // even if the pageload root span is still ongoing.
                    this._pageloadOngoing = false;
                }
                this._routingSpan =
                    runOutsideAngular(() => startInactiveSpan({
                        // With span streaming, span names have to be low cardinality. The parameterized route is only
                        // known at `ResolveEnd`, well after this span starts, so there is nothing but the fallback.
                        name: hasSpanStreamingEnabled(client) ? ROUTER_SPAN_NAME_FALLBACK : `${navigationEvent.url}`,
                        attributes: {
                            [SENTRY_OP]: ROUTER,
                            [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: 'auto.ui.angular',
                            [URL_FULL]: strippedUrl,
                            ...(navigationEvent.navigationTrigger && {
                                navigationTrigger: navigationEvent.navigationTrigger,
                            }),
                        },
                    })) || null;
                return;
            }
        }));
        // The ResolveEnd event is fired when the Angular router has resolved the URL and
        // the parameter<->value mapping. It holds the new resolved router state with
        // the mapping and the new URL.
        // Only After this event, the route is activated, meaning that the transaction
        // can be updated with the parameterized route name before e.g. the route's root
        // component is initialized. This should be early enough before outgoing requests
        // are made from the new route, with the exceptions of requests being made during
        // a navigation.
        this.resEnd$ = this._router.events.pipe(filter((event) => event instanceof ResolveEnd), tap(event => {
            const route = getParameterizedRouteFromSnapshot(event.state.root);
            if (route) {
                getCurrentScope().setTransactionName(route);
            }
            const activeSpan = getActiveSpan();
            const rootSpan = activeSpan && getRootSpan(activeSpan);
            _updateSpanAttributesForParametrizedUrl(route, event.urlAfterRedirects, rootSpan);
        }));
        this.navEnd$ = this._router.events.pipe(filter(event => event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError), tap(() => {
            if (this._routingSpan) {
                runOutsideAngular(() => {
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    this._routingSpan.end();
                });
                this._routingSpan = null;
            }
        }));
        this._routingSpan = null;
        this._pageloadOngoing = true;
        this._subscription = new Subscription();
        this._subscription.add(this.navStart$.subscribe());
        this._subscription.add(this.resEnd$.subscribe());
        this._subscription.add(this.navEnd$.subscribe());
    }
    /**
     * This is used to prevent memory leaks when the root view is created and destroyed multiple times,
     * since `subscribe` callbacks capture `this` and prevent many resources from being GC'd.
     */
    ngOnDestroy() {
        this._subscription.unsubscribe();
    }
    /**
     * We only _avoid_ creating a navigation root span in one case:
     *
     * There is an ongoing pageload span AND the router didn't yet emit the first navigation start event
     *
     * The first navigation start event will create the child routing span
     * and update the pageload root span name on ResolveEnd.
     *
     * There's an edge case we need to avoid here: If the router fires the first navigation start event
     * _after_ the pageload root span finished. This is why we check for the pageload root span.
     * Possible real-world scenario: Angular application and/or router is bootstrapped after the pageload
     * idle root span finished
     *
     * The overall rationale is:
     * - if we already avoided creating a navigation root span once, we don't avoid it again
     *   (i.e. set `_pageloadOngoing` to `false`)
     * - if `_pageloadOngoing` is already `false`, create a navigation root span
     * - if there's no active/pageload root span, create a navigation root span
     * - only if there's an ongoing pageload root span AND `_pageloadOngoing` is still `true,
     *   don't create a navigation root span
     */
    _isPageloadOngoing() {
        if (!this._pageloadOngoing) {
            // pageload is already finished, no need to update
            return false;
        }
        const activeSpan = getActiveSpan();
        if (!activeSpan) {
            this._pageloadOngoing = false;
            return false;
        }
        const rootSpan = getRootSpan(activeSpan);
        this._pageloadOngoing = spanToJSON(rootSpan).attributes[SENTRY_OP] === 'pageload';
        return this._pageloadOngoing;
    }
}
TraceService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceService, deps: [{ token: i1.Router }], target: i0.ɵɵFactoryTarget.Injectable });
TraceService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: function () { return [{ type: i1.Router }]; } });
/**
 * Captures the initialization lifecycle of the component this directive is applied to.
 * Specifically, this directive measures the time between `ngOnInit` and `ngAfterViewInit`
 * of the component.
 *
 * Falls back to the component's selector if no name is provided.
 *
 * @example
 * ```html
 * <app-my-component trace="myComponent"></app-my-component>
 * ```
 */
export class TraceDirective {
    constructor(_host) {
        this._host = _host;
    }
    /**
     * Implementation of OnInit lifecycle method
     * @inheritdoc
     */
    ngOnInit() {
        if (!this.componentName) {
            // Technically, the `trace` binding should always be provided.
            // However, if it is incorrectly declared on the element without a
            // value (e.g., `<app-component trace />`), we fall back to using `tagName`
            // (which is e.g. `APP-COMPONENT`).
            this.componentName = this._host.nativeElement.tagName.toLowerCase();
        }
        if (getActiveSpan()) {
            this._tracingSpan = runOutsideAngular(() => startInactiveSpan({
                name: `<${this.componentName}>`,
                attributes: {
                    [SENTRY_OP]: UI_MOUNT,
                    [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: 'auto.ui.angular.trace_directive',
                },
            }));
        }
    }
    /**
     * Implementation of AfterViewInit lifecycle method
     * @inheritdoc
     */
    ngAfterViewInit() {
        const span = this._tracingSpan;
        if (span) {
            runOutsideAngular(() => span.end());
        }
    }
}
TraceDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
TraceDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "14.3.0", type: TraceDirective, selector: "[trace]", inputs: { componentName: ["trace", "componentName"] }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[trace]' }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { componentName: [{
                type: Input,
                args: ['trace']
            }] } });
/**
 * A module serves as a single compilation unit for the `TraceDirective` and can be re-used by any other module.
 */
export class TraceModule {
}
TraceModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
TraceModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "14.3.0", ngImport: i0, type: TraceModule, declarations: [TraceDirective], exports: [TraceDirective] });
TraceModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceModule });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: TraceModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [TraceDirective],
                    exports: [TraceDirective],
                }]
        }] });
/**
 * Decorator function that can be used to capture initialization lifecycle of the whole component.
 */
export function TraceClass(options) {
    let tracingSpan;
    /* eslint-disable @typescript-eslint/no-unsafe-member-access */
    return target => {
        const originalOnInit = target.prototype.ngOnInit;
        target.prototype.ngOnInit = function (...args) {
            tracingSpan = runOutsideAngular(() => startInactiveSpan({
                onlyIfParent: true,
                name: `<${options?.name || 'unnamed'}>`,
                attributes: {
                    [SENTRY_OP]: UI_MOUNT,
                    [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: 'auto.ui.angular.trace_class_decorator',
                },
            }));
            if (originalOnInit) {
                return originalOnInit.apply(this, args);
            }
        };
        const originalAfterViewInit = target.prototype.ngAfterViewInit;
        target.prototype.ngAfterViewInit = function (...args) {
            if (tracingSpan) {
                runOutsideAngular(() => tracingSpan.end());
            }
            if (originalAfterViewInit) {
                return originalAfterViewInit.apply(this, args);
            }
        };
    };
    /* eslint-enable @typescript-eslint/no-unsafe-member-access */
}
/**
 * Decorator function that can be used to capture a single lifecycle methods of the component.
 */
export function TraceMethod(options) {
    return (_target, propertyKey, descriptor) => {
        const originalMethod = descriptor.value;
        descriptor.value = function (...args) {
            const now = timestampInSeconds();
            runOutsideAngular(() => {
                startInactiveSpan({
                    onlyIfParent: true,
                    name: `<${options?.name ? options.name : 'unnamed'}>`,
                    startTime: now,
                    attributes: {
                        [SENTRY_OP]: FUNCTION,
                        [SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN]: 'auto.ui.angular.trace_method_decorator',
                        [CODE_FUNCTION_NAME]: String(propertyKey),
                    },
                }).end(now);
            });
            if (originalMethod) {
                // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
                return originalMethod.apply(this, args);
            }
        };
        return descriptor;
    };
}
/**
 * Takes the parameterized route from a given ActivatedRouteSnapshot and concatenates the snapshot's
 * child route with its parent to produce the complete parameterized URL of the activated route.
 * This happens recursively until the last child (i.e. the end of the URL) is reached.
 *
 * @param route the ActivatedRouteSnapshot of which its path and its child's path is concatenated
 *
 * @returns the concatenated parameterized route string
 */
export function getParameterizedRouteFromSnapshot(route) {
    const parts = [];
    let currentRoute = route?.firstChild;
    while (currentRoute) {
        const path = currentRoute?.routeConfig && currentRoute.routeConfig.path;
        if (path === null || path === undefined) {
            break;
        }
        parts.push(path);
        currentRoute = currentRoute.firstChild;
    }
    const fullPath = parts.filter(part => part).join('/');
    return fullPath ? `/${fullPath}/` : '/';
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJhY2luZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy90cmFjaW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFdkUsZ0hBQWdIO0FBQ2hILCtFQUErRTtBQUMvRSxzRUFBc0U7QUFDdEUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLGVBQWUsRUFBVSxNQUFNLGlCQUFpQixDQUFDO0FBQzVFLE9BQU8sRUFBRSxhQUFhLEVBQUUsZUFBZSxFQUFFLFVBQVUsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzdFLE9BQU8sRUFDTCx5QkFBeUIsSUFBSSxpQ0FBaUMsRUFDOUQsYUFBYSxFQUNiLFNBQVMsRUFDVCxlQUFlLEVBQ2YsV0FBVyxFQUNYLGdDQUFnQyxFQUNoQyxVQUFVLEVBQ1YsaUNBQWlDLEVBQ2pDLGlCQUFpQixFQUNqQixjQUFjLEdBQ2YsTUFBTSxpQkFBaUIsQ0FBQztBQUN6QixPQUFPLEVBQ0wsMEJBQTBCLEVBQzFCLGtCQUFrQixFQUNsQixTQUFTLEVBQ1QsUUFBUSxFQUNSLFFBQVEsRUFDUixZQUFZLEdBQ2IsTUFBTSxnQ0FBZ0MsQ0FBQztBQUN4QyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBRTFELE9BQU8sRUFDTCxLQUFLLEVBQ0wsdUJBQXVCLEVBQ3ZCLDZCQUE2QixFQUM3QixzQkFBc0IsRUFDdEIseUJBQXlCLEVBQ3pCLHdCQUF3QixFQUN4QixrQkFBa0IsRUFDbEIsa0JBQWtCLEdBQ25CLE1BQU0sY0FBYyxDQUFDO0FBRXRCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDcEMsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM3QyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDbEQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLFNBQVMsQ0FBQztBQUN6QyxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxRQUFRLENBQUM7OztBQUUzQyxJQUFJLDBCQUFtQyxDQUFDO0FBRXhDOzs7O0dBSUc7QUFDSCxNQUFNLFVBQVUseUJBQXlCLENBQ3ZDLFVBQW1FLEVBQUU7SUFFckUsc0VBQXNFO0lBQ3RFLHlGQUF5RjtJQUN6RixJQUFJLE9BQU8sQ0FBQyxvQkFBb0IsS0FBSyxLQUFLLEVBQUU7UUFDMUMsMEJBQTBCLEdBQUcsSUFBSSxDQUFDO0tBQ25DO0lBRUQsT0FBTyxpQ0FBaUMsQ0FBQztRQUN2QyxHQUFHLE9BQU87UUFDVixvQkFBb0IsRUFBRSxLQUFLO0tBQzVCLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRDs7R0FFRztBQUNILE1BQU0sVUFBVSx1Q0FBdUMsQ0FBQyxLQUFhLEVBQUUsR0FBVyxFQUFFLElBQVc7SUFDN0YsSUFBSSxDQUFDLElBQUksRUFBRTtRQUNULE9BQU87S0FDUjtJQUVELE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUM7SUFFL0MsSUFBSSxDQUFDLFVBQVUsSUFBSSxVQUFVLENBQUMsMEJBQTBCLENBQUMsS0FBSyxLQUFLLEVBQUU7UUFDbkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV2QixNQUFNLFdBQVcsR0FBRyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFeEMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUNqQixDQUFDLGdDQUFnQyxDQUFDLEVBQUUsUUFBUSxVQUFVLENBQUMsU0FBUyxDQUFDLFVBQVU7WUFDM0UsQ0FBQywwQkFBMEIsQ0FBQyxFQUFFLE9BQU87WUFDckMsQ0FBQyxRQUFRLENBQUMsRUFBRSxrQkFBa0IsQ0FBQyxXQUFXLENBQUM7WUFDM0MsQ0FBQyxRQUFRLENBQUMsRUFBRSxzQkFBc0IsQ0FBQyxXQUFXLENBQUMsRUFBRSxRQUFRO1lBQ3pELENBQUMsWUFBWSxDQUFDLEVBQUUsS0FBSztTQUN0QixDQUFDLENBQUM7S0FDSjtBQUNILENBQUM7QUFFRDs7O0dBR0c7QUFFSCxNQUFNLE9BQU8sWUFBWTtJQXFIdkIsWUFBb0MsT0FBZTtRQUFmLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFwSDVDLGNBQVMsR0FBc0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUM1RCxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQTRCLEVBQUUsQ0FBQyxLQUFLLFlBQVksZUFBZSxDQUFDLEVBQzdFLEdBQUcsQ0FBQyxlQUFlLENBQUMsRUFBRTtZQUNwQixJQUFJLENBQUMsMEJBQTBCLEVBQUU7Z0JBQy9CLGNBQWM7b0JBQ1osS0FBSyxDQUFDLEtBQUssQ0FBQyxvRkFBb0YsQ0FBQyxDQUFDO2dCQUNwRyxPQUFPO2FBQ1I7WUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2FBQzFCO1lBRUQsTUFBTSxNQUFNLEdBQUcsU0FBUyxFQUFFLENBQUM7WUFDM0IsTUFBTSxXQUFXLEdBQUcsd0JBQXdCLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRWxFLElBQUksTUFBTSxFQUFFO2dCQUNWLG9EQUFvRDtnQkFDcEQsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFO29CQUM5QixpQkFBaUIsQ0FBQyxHQUFHLEVBQUU7d0JBQ3JCLGlDQUFpQyxDQUMvQixNQUFNLEVBQ047NEJBQ0Usc0ZBQXNGOzRCQUN0RixtRUFBbUU7NEJBQ25FLElBQUksRUFBRSx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLFdBQVc7NEJBQ25GLFVBQVUsRUFBRTtnQ0FDVixDQUFDLGdDQUFnQyxDQUFDLEVBQUUseUJBQXlCO2dDQUM3RCxDQUFDLDBCQUEwQixDQUFDLEVBQUUsS0FBSzs2QkFDcEM7eUJBQ0YsRUFDRDs0QkFDRSxHQUFHLEVBQUUsY0FBYyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUM7eUJBQ3pDLENBQ0YsQ0FBQztvQkFDSixDQUFDLENBQUMsQ0FBQztpQkFDSjtxQkFBTTtvQkFDTCxtRUFBbUU7b0JBQ25FLHlFQUF5RTtvQkFDekUsbURBQW1EO29CQUNuRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO2lCQUMvQjtnQkFFRCxJQUFJLENBQUMsWUFBWTtvQkFDZixpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsQ0FDckIsaUJBQWlCLENBQUM7d0JBQ2hCLDhGQUE4Rjt3QkFDOUYsNEZBQTRGO3dCQUM1RixJQUFJLEVBQUUsdUJBQXVCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxHQUFHLEVBQUU7d0JBQzVGLFVBQVUsRUFBRTs0QkFDVixDQUFDLFNBQVMsQ0FBQyxFQUFFLE1BQU07NEJBQ25CLENBQUMsZ0NBQWdDLENBQUMsRUFBRSxpQkFBaUI7NEJBQ3JELENBQUMsUUFBUSxDQUFDLEVBQUUsV0FBVzs0QkFDdkIsR0FBRyxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsSUFBSTtnQ0FDdkMsaUJBQWlCLEVBQUUsZUFBZSxDQUFDLGlCQUFpQjs2QkFDckQsQ0FBQzt5QkFDSDtxQkFDRixDQUFDLENBQ0gsSUFBSSxJQUFJLENBQUM7Z0JBRVosT0FBTzthQUNSO1FBQ0gsQ0FBQyxDQUFDLENBQ0gsQ0FBQztRQUVGLGlGQUFpRjtRQUNqRiw2RUFBNkU7UUFDN0UsK0JBQStCO1FBQy9CLDhFQUE4RTtRQUM5RSxnRkFBZ0Y7UUFDaEYsaUZBQWlGO1FBQ2pGLGlGQUFpRjtRQUNqRixnQkFBZ0I7UUFDVCxZQUFPLEdBQXNCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FDMUQsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUF1QixFQUFFLENBQUMsS0FBSyxZQUFZLFVBQVUsQ0FBQyxFQUNuRSxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDVixNQUFNLEtBQUssR0FBRyxpQ0FBaUMsQ0FDNUMsS0FBSyxDQUFDLEtBQW1FLENBQUMsSUFBSSxDQUNoRixDQUFDO1lBRUYsSUFBSSxLQUFLLEVBQUU7Z0JBQ1QsZUFBZSxFQUFFLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDN0M7WUFFRCxNQUFNLFVBQVUsR0FBRyxhQUFhLEVBQUUsQ0FBQztZQUNuQyxNQUFNLFFBQVEsR0FBRyxVQUFVLElBQUksV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXZELHVDQUF1QyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDcEYsQ0FBQyxDQUFDLENBQ0gsQ0FBQztRQUVLLFlBQU8sR0FBc0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUMxRCxNQUFNLENBQ0osS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLFlBQVksYUFBYSxJQUFJLEtBQUssWUFBWSxnQkFBZ0IsSUFBSSxLQUFLLFlBQVksZUFBZSxDQUNqSCxFQUNELEdBQUcsQ0FBQyxHQUFHLEVBQUU7WUFDUCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ3JCLGlCQUFpQixDQUFDLEdBQUcsRUFBRTtvQkFDckIsb0VBQW9FO29CQUNwRSxJQUFJLENBQUMsWUFBYSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUMzQixDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQzthQUMxQjtRQUNILENBQUMsQ0FBQyxDQUNILENBQUM7UUFZQSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztRQUN6QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1FBRTdCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUV4QyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksV0FBVztRQUNoQixJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FvQkc7SUFDSyxrQkFBa0I7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUMxQixrREFBa0Q7WUFDbEQsT0FBTyxLQUFLLENBQUM7U0FDZDtRQUVELE1BQU0sVUFBVSxHQUFHLGFBQWEsRUFBRSxDQUFDO1FBQ25DLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDZixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBQzlCLE9BQU8sS0FBSyxDQUFDO1NBQ2Q7UUFFRCxNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFekMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEtBQUssVUFBVSxDQUFDO1FBQ2xGLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7O3lHQTdLVSxZQUFZOzZHQUFaLFlBQVksY0FEQyxNQUFNOzJGQUNuQixZQUFZO2tCQUR4QixVQUFVO21CQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRTs7QUFpTGxDOzs7Ozs7Ozs7OztHQVdHO0FBRUgsTUFBTSxPQUFPLGNBQWM7SUFLekIsWUFBb0MsS0FBOEI7UUFBOUIsVUFBSyxHQUFMLEtBQUssQ0FBeUI7SUFBRyxDQUFDO0lBRXRFOzs7T0FHRztJQUNJLFFBQVE7UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUN2Qiw4REFBOEQ7WUFDOUQsa0VBQWtFO1lBQ2xFLDJFQUEyRTtZQUMzRSxtQ0FBbUM7WUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDckU7UUFFRCxJQUFJLGFBQWEsRUFBRSxFQUFFO1lBQ25CLElBQUksQ0FBQyxZQUFZLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQ3pDLGlCQUFpQixDQUFDO2dCQUNoQixJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsYUFBYSxHQUFHO2dCQUMvQixVQUFVLEVBQUU7b0JBQ1YsQ0FBQyxTQUFTLENBQUMsRUFBRSxRQUFRO29CQUNyQixDQUFDLGdDQUFnQyxDQUFDLEVBQUUsaUNBQWlDO2lCQUN0RTthQUNGLENBQUMsQ0FDSCxDQUFDO1NBQ0g7SUFDSCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksZUFBZTtRQUNwQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQy9CLElBQUksSUFBSSxFQUFFO1lBQ1IsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7U0FDckM7SUFDSCxDQUFDOzsyR0ExQ1UsY0FBYzsrRkFBZCxjQUFjOzJGQUFkLGNBQWM7a0JBRDFCLFNBQVM7bUJBQUMsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFO2lHQUVULGFBQWE7c0JBQW5DLEtBQUs7dUJBQUMsT0FBTzs7QUE0Q2hCOztHQUVHO0FBS0gsTUFBTSxPQUFPLFdBQVc7O3dHQUFYLFdBQVc7eUdBQVgsV0FBVyxpQkFwRFgsY0FBYyxhQUFkLGNBQWM7eUdBb0RkLFdBQVc7MkZBQVgsV0FBVztrQkFKdkIsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUUsQ0FBQyxjQUFjLENBQUM7b0JBQzlCLE9BQU8sRUFBRSxDQUFDLGNBQWMsQ0FBQztpQkFDMUI7O0FBVUQ7O0dBRUc7QUFDSCxNQUFNLFVBQVUsVUFBVSxDQUFDLE9BQTJCO0lBQ3BELElBQUksV0FBaUIsQ0FBQztJQUV0QiwrREFBK0Q7SUFDL0QsT0FBTyxNQUFNLENBQUMsRUFBRTtRQUNkLE1BQU0sY0FBYyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBQ2pELE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLFVBQVUsR0FBRyxJQUFlO1lBQ3RELFdBQVcsR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsQ0FDbkMsaUJBQWlCLENBQUM7Z0JBQ2hCLFlBQVksRUFBRSxJQUFJO2dCQUNsQixJQUFJLEVBQUUsSUFBSSxPQUFPLEVBQUUsSUFBSSxJQUFJLFNBQVMsR0FBRztnQkFDdkMsVUFBVSxFQUFFO29CQUNWLENBQUMsU0FBUyxDQUFDLEVBQUUsUUFBUTtvQkFDckIsQ0FBQyxnQ0FBZ0MsQ0FBQyxFQUFFLHVDQUF1QztpQkFDNUU7YUFDRixDQUFDLENBQ0gsQ0FBQztZQUVGLElBQUksY0FBYyxFQUFFO2dCQUNsQixPQUFPLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3pDO1FBQ0gsQ0FBQyxDQUFDO1FBRUYsTUFBTSxxQkFBcUIsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztRQUMvRCxNQUFNLENBQUMsU0FBUyxDQUFDLGVBQWUsR0FBRyxVQUFVLEdBQUcsSUFBZTtZQUM3RCxJQUFJLFdBQVcsRUFBRTtnQkFDZixpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzthQUM1QztZQUNELElBQUkscUJBQXFCLEVBQUU7Z0JBQ3pCLE9BQU8scUJBQXFCLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNoRDtRQUNILENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztJQUNGLDhEQUE4RDtBQUNoRSxDQUFDO0FBU0Q7O0dBRUc7QUFDSCxNQUFNLFVBQVUsV0FBVyxDQUFDLE9BQTRCO0lBQ3RELE9BQU8sQ0FBQyxPQUFnQixFQUFFLFdBQTRCLEVBQUUsVUFBOEIsRUFBRSxFQUFFO1FBQ3hGLE1BQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7UUFDeEMsVUFBVSxDQUFDLEtBQUssR0FBRyxVQUFVLEdBQUcsSUFBZTtZQUM3QyxNQUFNLEdBQUcsR0FBRyxrQkFBa0IsRUFBRSxDQUFDO1lBRWpDLGlCQUFpQixDQUFDLEdBQUcsRUFBRTtnQkFDckIsaUJBQWlCLENBQUM7b0JBQ2hCLFlBQVksRUFBRSxJQUFJO29CQUNsQixJQUFJLEVBQUUsSUFBSSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUc7b0JBQ3JELFNBQVMsRUFBRSxHQUFHO29CQUNkLFVBQVUsRUFBRTt3QkFDVixDQUFDLFNBQVMsQ0FBQyxFQUFFLFFBQVE7d0JBQ3JCLENBQUMsZ0NBQWdDLENBQUMsRUFBRSx3Q0FBd0M7d0JBQzVFLENBQUMsa0JBQWtCLENBQUMsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDO3FCQUMxQztpQkFDRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2QsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLGNBQWMsRUFBRTtnQkFDbEIsc0VBQXNFO2dCQUN0RSxPQUFPLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3pDO1FBQ0gsQ0FBQyxDQUFDO1FBQ0YsT0FBTyxVQUFVLENBQUM7SUFDcEIsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxVQUFVLGlDQUFpQyxDQUFDLEtBQXFDO0lBQ3JGLE1BQU0sS0FBSyxHQUFhLEVBQUUsQ0FBQztJQUUzQixJQUFJLFlBQVksR0FBRyxLQUFLLEVBQUUsVUFBVSxDQUFDO0lBQ3JDLE9BQU8sWUFBWSxFQUFFO1FBQ25CLE1BQU0sSUFBSSxHQUFHLFlBQVksRUFBRSxXQUFXLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7UUFDeEUsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDdkMsTUFBTTtTQUNQO1FBRUQsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqQixZQUFZLEdBQUcsWUFBWSxDQUFDLFVBQVUsQ0FBQztLQUN4QztJQUVELE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDdEQsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3ksIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9jb25zaXN0ZW50LXR5cGUtaW1wb3J0c1xuaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRGlyZWN0aXZlLCBJbmplY3RhYmxlLCBJbnB1dCwgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB0eXBlIHsgQWN0aXZhdGVkUm91dGVTbmFwc2hvdCwgRXZlbnQsIFJvdXRlclN0YXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbi8vIER1cGxpY2F0ZWQgaW1wb3J0IHRvIHdvcmsgYXJvdW5kIGEgVHlwZVNjcmlwdCBidWcgd2hlcmUgaXQnZCBjb21wbGFpbiB0aGF0IGBSb3V0ZXJgIGlzbid0IGltcG9ydGVkIGFzIGEgdHlwZS5cbi8vIFdlIG5lZWQgdG8gaW1wb3J0IGl0IGFzIGEgdmFsdWUgdG8gc2F0aXNmeSBBbmd1bGFyIGRlcGVuZGVuY3kgaW5qZWN0aW9uLiBTbzpcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvY29uc2lzdGVudC10eXBlLWltcG9ydHNcbmltcG9ydCB7IE5hdmlnYXRpb25DYW5jZWwsIE5hdmlnYXRpb25FcnJvciwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IE5hdmlnYXRpb25FbmQsIE5hdmlnYXRpb25TdGFydCwgUmVzb2x2ZUVuZCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XG5pbXBvcnQge1xuICBicm93c2VyVHJhY2luZ0ludGVncmF0aW9uIGFzIG9yaWdpbmFsQnJvd3NlclRyYWNpbmdJbnRlZ3JhdGlvbixcbiAgZ2V0QWN0aXZlU3BhbixcbiAgZ2V0Q2xpZW50LFxuICBnZXRDdXJyZW50U2NvcGUsXG4gIGdldFJvb3RTcGFuLFxuICBTRU1BTlRJQ19BVFRSSUJVVEVfU0VOVFJZX09SSUdJTixcbiAgc3BhblRvSlNPTixcbiAgc3RhcnRCcm93c2VyVHJhY2luZ05hdmlnYXRpb25TcGFuLFxuICBzdGFydEluYWN0aXZlU3BhbixcbiAgZ2V0QWJzb2x1dGVVcmwsXG59IGZyb20gJ0BzZW50cnkvYnJvd3Nlcic7XG5pbXBvcnQge1xuICBTRU5UUllfU0VHTUVOVF9OQU1FX1NPVVJDRSxcbiAgQ09ERV9GVU5DVElPTl9OQU1FLFxuICBTRU5UUllfT1AsXG4gIFVSTF9GVUxMLFxuICBVUkxfUEFUSCxcbiAgVVJMX1RFTVBMQVRFLFxufSBmcm9tICdAc2VudHJ5L2NvbnZlbnRpb25zL2F0dHJpYnV0ZXMnO1xuaW1wb3J0IHsgRlVOQ1RJT04sIFJPVVRFUiB9IGZyb20gJ0BzZW50cnkvY29udmVudGlvbnMvb3AnO1xuaW1wb3J0IHR5cGUgeyBJbnRlZ3JhdGlvbiwgU3BhbiB9IGZyb20gJ0BzZW50cnkvY29yZSc7XG5pbXBvcnQge1xuICBkZWJ1ZyxcbiAgaGFzU3BhblN0cmVhbWluZ0VuYWJsZWQsXG4gIE5BVklHQVRJT05fU1BBTl9OQU1FX0ZBTExCQUNLLFxuICBwYXJzZVN0cmluZ1RvVVJMT2JqZWN0LFxuICBST1VURVJfU1BBTl9OQU1FX0ZBTExCQUNLLFxuICBzdHJpcFVybFF1ZXJ5QW5kRnJhZ21lbnQsXG4gIHRpbWVzdGFtcEluU2Vjb25kcyxcbiAgZmlsdGVyQ29sbGVjdGVkVXJsLFxufSBmcm9tICdAc2VudHJ5L2NvcmUnO1xuaW1wb3J0IHR5cGUgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbHRlciwgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgVUlfTU9VTlQgfSBmcm9tICdAc2VudHJ5L2NvbnZlbnRpb25zL29wJztcbmltcG9ydCB7IElTX0RFQlVHX0JVSUxEIH0gZnJvbSAnLi9mbGFncyc7XG5pbXBvcnQgeyBydW5PdXRzaWRlQW5ndWxhciB9IGZyb20gJy4vem9uZSc7XG5cbmxldCBpbnN0cnVtZW50YXRpb25Jbml0aWFsaXplZDogYm9vbGVhbjtcblxuLyoqXG4gKiBBIGN1c3RvbSBicm93c2VyIHRyYWNpbmcgaW50ZWdyYXRpb24gZm9yIEFuZ3VsYXIuXG4gKlxuICogVXNlIHRoaXMgaW50ZWdyYXRpb24gaW4gY29tYmluYXRpb24gd2l0aCBgVHJhY2VTZXJ2aWNlYFxuICovXG5leHBvcnQgZnVuY3Rpb24gYnJvd3NlclRyYWNpbmdJbnRlZ3JhdGlvbihcbiAgb3B0aW9uczogUGFyYW1ldGVyczx0eXBlb2Ygb3JpZ2luYWxCcm93c2VyVHJhY2luZ0ludGVncmF0aW9uPlswXSA9IHt9LFxuKTogSW50ZWdyYXRpb24ge1xuICAvLyBJZiB0aGUgdXNlciBvcHRzIG91dCB0byBzZXQgdGhpcyB1cCwgd2UganVzdCBkb24ndCBpbml0aWFsaXplIHRoaXMuXG4gIC8vIFRoYXQgd2F5LCB0aGUgVHJhY2VTZXJ2aWNlIHdpbGwgbm90IGFjdHVhbGx5IGRvIGFueXRoaW5nLCBmdW5jdGlvbmFsbHkgZGlzYWJsaW5nIHRoaXMuXG4gIGlmIChvcHRpb25zLmluc3RydW1lbnROYXZpZ2F0aW9uICE9PSBmYWxzZSkge1xuICAgIGluc3RydW1lbnRhdGlvbkluaXRpYWxpemVkID0gdHJ1ZTtcbiAgfVxuXG4gIHJldHVybiBvcmlnaW5hbEJyb3dzZXJUcmFjaW5nSW50ZWdyYXRpb24oe1xuICAgIC4uLm9wdGlvbnMsXG4gICAgaW5zdHJ1bWVudE5hdmlnYXRpb246IGZhbHNlLFxuICB9KTtcbn1cblxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGlzIGV4dHJhY3RlZCB0byBtYWtlIHVuaXQgdGVzdGluZyBlYXNpZXIuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBfdXBkYXRlU3BhbkF0dHJpYnV0ZXNGb3JQYXJhbWV0cml6ZWRVcmwocm91dGU6IHN0cmluZywgdXJsOiBzdHJpbmcsIHNwYW4/OiBTcGFuKTogdm9pZCB7XG4gIGlmICghc3Bhbikge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGF0dHJpYnV0ZXMgPSBzcGFuVG9KU09OKHNwYW4pLmF0dHJpYnV0ZXM7XG5cbiAgaWYgKCFhdHRyaWJ1dGVzIHx8IGF0dHJpYnV0ZXNbU0VOVFJZX1NFR01FTlRfTkFNRV9TT1VSQ0VdID09PSAndXJsJykge1xuICAgIHNwYW4udXBkYXRlTmFtZShyb3V0ZSk7XG5cbiAgICBjb25zdCBhYnNvbHV0ZVVybCA9IGdldEFic29sdXRlVXJsKHVybCk7XG5cbiAgICBzcGFuLnNldEF0dHJpYnV0ZXMoe1xuICAgICAgW1NFTUFOVElDX0FUVFJJQlVURV9TRU5UUllfT1JJR0lOXTogYGF1dG8uJHthdHRyaWJ1dGVzW1NFTlRSWV9PUF19LmFuZ3VsYXJgLFxuICAgICAgW1NFTlRSWV9TRUdNRU5UX05BTUVfU09VUkNFXTogJ3JvdXRlJyxcbiAgICAgIFtVUkxfRlVMTF06IGZpbHRlckNvbGxlY3RlZFVybChhYnNvbHV0ZVVybCksXG4gICAgICBbVVJMX1BBVEhdOiBwYXJzZVN0cmluZ1RvVVJMT2JqZWN0KGFic29sdXRlVXJsKT8ucGF0aG5hbWUsXG4gICAgICBbVVJMX1RFTVBMQVRFXTogcm91dGUsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBBbmd1bGFyJ3MgU2VydmljZSByZXNwb25zaWJsZSBmb3IgaG9va2luZyBpbnRvIEFuZ3VsYXIgUm91dGVyIGFuZCB0cmFja2luZyBjdXJyZW50IG5hdmlnYXRpb24gcHJvY2Vzcy5cbiAqIENyZWF0ZXMgYSBuZXcgdHJhbnNhY3Rpb24gZm9yIGV2ZXJ5IHJvdXRlIGNoYW5nZSBhbmQgbWVhc3VyZXMgYSBkdXJhdGlvbiBvZiByb3V0aW5nIHByb2Nlc3MuXG4gKi9cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgVHJhY2VTZXJ2aWNlIGltcGxlbWVudHMgT25EZXN0cm95IHtcbiAgcHVibGljIG5hdlN0YXJ0JDogT2JzZXJ2YWJsZTxFdmVudD4gPSB0aGlzLl9yb3V0ZXIuZXZlbnRzLnBpcGUoXG4gICAgZmlsdGVyKChldmVudCk6IGV2ZW50IGlzIE5hdmlnYXRpb25TdGFydCA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25TdGFydCksXG4gICAgdGFwKG5hdmlnYXRpb25FdmVudCA9PiB7XG4gICAgICBpZiAoIWluc3RydW1lbnRhdGlvbkluaXRpYWxpemVkKSB7XG4gICAgICAgIElTX0RFQlVHX0JVSUxEICYmXG4gICAgICAgICAgZGVidWcuZXJyb3IoJ0FuZ3VsYXIgaW50ZWdyYXRpb24gaGFzIHRyYWNpbmcgZW5hYmxlZCwgYnV0IFRyYWNpbmcgaW50ZWdyYXRpb24gaXMgbm90IGNvbmZpZ3VyZWQnKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5fcm91dGluZ1NwYW4pIHtcbiAgICAgICAgdGhpcy5fcm91dGluZ1NwYW4uZW5kKCk7XG4gICAgICAgIHRoaXMuX3JvdXRpbmdTcGFuID0gbnVsbDtcbiAgICAgIH1cblxuICAgICAgY29uc3QgY2xpZW50ID0gZ2V0Q2xpZW50KCk7XG4gICAgICBjb25zdCBzdHJpcHBlZFVybCA9IHN0cmlwVXJsUXVlcnlBbmRGcmFnbWVudChuYXZpZ2F0aW9uRXZlbnQudXJsKTtcblxuICAgICAgaWYgKGNsaWVudCkge1xuICAgICAgICAvLyBzZWUgY29tbWVudCBpbiBgX2lzUGFnZWxvYWRPbmdvaW5nYCBmb3IgcmF0aW9uYWxlXG4gICAgICAgIGlmICghdGhpcy5faXNQYWdlbG9hZE9uZ29pbmcoKSkge1xuICAgICAgICAgIHJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgICAgICAgIHN0YXJ0QnJvd3NlclRyYWNpbmdOYXZpZ2F0aW9uU3BhbihcbiAgICAgICAgICAgICAgY2xpZW50LFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgLy8gV2l0aCBzcGFuIHN0cmVhbWluZywgc3BhbiBuYW1lcyBoYXZlIHRvIGJlIGxvdyBjYXJkaW5hbGl0eS4gVGhlIHBhcmFtZXRlcml6ZWQgcm91dGVcbiAgICAgICAgICAgICAgICAvLyBpcyBvbmx5IGtub3duIG9uIGBSZXNvbHZlRW5kYCwgd2hpY2ggdXBkYXRlcyB0aGUgc3BhbiBuYW1lIHRoZW4uXG4gICAgICAgICAgICAgICAgbmFtZTogaGFzU3BhblN0cmVhbWluZ0VuYWJsZWQoY2xpZW50KSA/IE5BVklHQVRJT05fU1BBTl9OQU1FX0ZBTExCQUNLIDogc3RyaXBwZWRVcmwsXG4gICAgICAgICAgICAgICAgYXR0cmlidXRlczoge1xuICAgICAgICAgICAgICAgICAgW1NFTUFOVElDX0FUVFJJQlVURV9TRU5UUllfT1JJR0lOXTogJ2F1dG8ubmF2aWdhdGlvbi5hbmd1bGFyJyxcbiAgICAgICAgICAgICAgICAgIFtTRU5UUllfU0VHTUVOVF9OQU1FX1NPVVJDRV06ICd1cmwnLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB1cmw6IGdldEFic29sdXRlVXJsKG5hdmlnYXRpb25FdmVudC51cmwpLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBUaGUgZmlyc3QgdGltZSB3ZSBlbmQgdXAgaGVyZSwgd2Ugc2V0IHRoZSBwYWdlbG9hZCBmbGFnIHRvIGZhbHNlXG4gICAgICAgICAgLy8gU3Vic2VxdWVudCBuYXZpZ2F0aW9ucyBhcmUgZ29pbmcgdG8gZ2V0IHRoZWlyIG93biBuYXZpZ2F0aW9uIHJvb3Qgc3BhblxuICAgICAgICAgIC8vIGV2ZW4gaWYgdGhlIHBhZ2Vsb2FkIHJvb3Qgc3BhbiBpcyBzdGlsbCBvbmdvaW5nLlxuICAgICAgICAgIHRoaXMuX3BhZ2Vsb2FkT25nb2luZyA9IGZhbHNlO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fcm91dGluZ1NwYW4gPVxuICAgICAgICAgIHJ1bk91dHNpZGVBbmd1bGFyKCgpID0+XG4gICAgICAgICAgICBzdGFydEluYWN0aXZlU3Bhbih7XG4gICAgICAgICAgICAgIC8vIFdpdGggc3BhbiBzdHJlYW1pbmcsIHNwYW4gbmFtZXMgaGF2ZSB0byBiZSBsb3cgY2FyZGluYWxpdHkuIFRoZSBwYXJhbWV0ZXJpemVkIHJvdXRlIGlzIG9ubHlcbiAgICAgICAgICAgICAgLy8ga25vd24gYXQgYFJlc29sdmVFbmRgLCB3ZWxsIGFmdGVyIHRoaXMgc3BhbiBzdGFydHMsIHNvIHRoZXJlIGlzIG5vdGhpbmcgYnV0IHRoZSBmYWxsYmFjay5cbiAgICAgICAgICAgICAgbmFtZTogaGFzU3BhblN0cmVhbWluZ0VuYWJsZWQoY2xpZW50KSA/IFJPVVRFUl9TUEFOX05BTUVfRkFMTEJBQ0sgOiBgJHtuYXZpZ2F0aW9uRXZlbnQudXJsfWAsXG4gICAgICAgICAgICAgIGF0dHJpYnV0ZXM6IHtcbiAgICAgICAgICAgICAgICBbU0VOVFJZX09QXTogUk9VVEVSLFxuICAgICAgICAgICAgICAgIFtTRU1BTlRJQ19BVFRSSUJVVEVfU0VOVFJZX09SSUdJTl06ICdhdXRvLnVpLmFuZ3VsYXInLFxuICAgICAgICAgICAgICAgIFtVUkxfRlVMTF06IHN0cmlwcGVkVXJsLFxuICAgICAgICAgICAgICAgIC4uLihuYXZpZ2F0aW9uRXZlbnQubmF2aWdhdGlvblRyaWdnZXIgJiYge1xuICAgICAgICAgICAgICAgICAgbmF2aWdhdGlvblRyaWdnZXI6IG5hdmlnYXRpb25FdmVudC5uYXZpZ2F0aW9uVHJpZ2dlcixcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICkgfHwgbnVsbDtcblxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfSksXG4gICk7XG5cbiAgLy8gVGhlIFJlc29sdmVFbmQgZXZlbnQgaXMgZmlyZWQgd2hlbiB0aGUgQW5ndWxhciByb3V0ZXIgaGFzIHJlc29sdmVkIHRoZSBVUkwgYW5kXG4gIC8vIHRoZSBwYXJhbWV0ZXI8LT52YWx1ZSBtYXBwaW5nLiBJdCBob2xkcyB0aGUgbmV3IHJlc29sdmVkIHJvdXRlciBzdGF0ZSB3aXRoXG4gIC8vIHRoZSBtYXBwaW5nIGFuZCB0aGUgbmV3IFVSTC5cbiAgLy8gT25seSBBZnRlciB0aGlzIGV2ZW50LCB0aGUgcm91dGUgaXMgYWN0aXZhdGVkLCBtZWFuaW5nIHRoYXQgdGhlIHRyYW5zYWN0aW9uXG4gIC8vIGNhbiBiZSB1cGRhdGVkIHdpdGggdGhlIHBhcmFtZXRlcml6ZWQgcm91dGUgbmFtZSBiZWZvcmUgZS5nLiB0aGUgcm91dGUncyByb290XG4gIC8vIGNvbXBvbmVudCBpcyBpbml0aWFsaXplZC4gVGhpcyBzaG91bGQgYmUgZWFybHkgZW5vdWdoIGJlZm9yZSBvdXRnb2luZyByZXF1ZXN0c1xuICAvLyBhcmUgbWFkZSBmcm9tIHRoZSBuZXcgcm91dGUsIHdpdGggdGhlIGV4Y2VwdGlvbnMgb2YgcmVxdWVzdHMgYmVpbmcgbWFkZSBkdXJpbmdcbiAgLy8gYSBuYXZpZ2F0aW9uLlxuICBwdWJsaWMgcmVzRW5kJDogT2JzZXJ2YWJsZTxFdmVudD4gPSB0aGlzLl9yb3V0ZXIuZXZlbnRzLnBpcGUoXG4gICAgZmlsdGVyKChldmVudCk6IGV2ZW50IGlzIFJlc29sdmVFbmQgPT4gZXZlbnQgaW5zdGFuY2VvZiBSZXNvbHZlRW5kKSxcbiAgICB0YXAoZXZlbnQgPT4ge1xuICAgICAgY29uc3Qgcm91dGUgPSBnZXRQYXJhbWV0ZXJpemVkUm91dGVGcm9tU25hcHNob3QoXG4gICAgICAgIChldmVudC5zdGF0ZSBhcyB1bmtub3duIGFzIFJvdXRlclN0YXRlICYgeyByb290OiBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90IH0pLnJvb3QsXG4gICAgICApO1xuXG4gICAgICBpZiAocm91dGUpIHtcbiAgICAgICAgZ2V0Q3VycmVudFNjb3BlKCkuc2V0VHJhbnNhY3Rpb25OYW1lKHJvdXRlKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgYWN0aXZlU3BhbiA9IGdldEFjdGl2ZVNwYW4oKTtcbiAgICAgIGNvbnN0IHJvb3RTcGFuID0gYWN0aXZlU3BhbiAmJiBnZXRSb290U3BhbihhY3RpdmVTcGFuKTtcblxuICAgICAgX3VwZGF0ZVNwYW5BdHRyaWJ1dGVzRm9yUGFyYW1ldHJpemVkVXJsKHJvdXRlLCBldmVudC51cmxBZnRlclJlZGlyZWN0cywgcm9vdFNwYW4pO1xuICAgIH0pLFxuICApO1xuXG4gIHB1YmxpYyBuYXZFbmQkOiBPYnNlcnZhYmxlPEV2ZW50PiA9IHRoaXMuX3JvdXRlci5ldmVudHMucGlwZShcbiAgICBmaWx0ZXIoXG4gICAgICBldmVudCA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQgfHwgZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uQ2FuY2VsIHx8IGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVycm9yLFxuICAgICksXG4gICAgdGFwKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLl9yb3V0aW5nU3Bhbikge1xuICAgICAgICBydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB7XG4gICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1ub24tbnVsbC1hc3NlcnRpb25cbiAgICAgICAgICB0aGlzLl9yb3V0aW5nU3BhbiEuZW5kKCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLl9yb3V0aW5nU3BhbiA9IG51bGw7XG4gICAgICB9XG4gICAgfSksXG4gICk7XG5cbiAgcHJpdmF0ZSBfcm91dGluZ1NwYW46IFNwYW4gfCBudWxsO1xuXG4gIHByaXZhdGUgX3N1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xuXG4gIC8qKlxuICAgKiBAc2VlIF9pc1BhZ2Vsb2FkT25nb2luZygpXG4gICAqL1xuICBwcml2YXRlIF9wYWdlbG9hZE9uZ29pbmc6IGJvb2xlYW47XG5cbiAgcHVibGljIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgX3JvdXRlcjogUm91dGVyKSB7XG4gICAgdGhpcy5fcm91dGluZ1NwYW4gPSBudWxsO1xuICAgIHRoaXMuX3BhZ2Vsb2FkT25nb2luZyA9IHRydWU7XG5cbiAgICB0aGlzLl9zdWJzY3JpcHRpb24gPSBuZXcgU3Vic2NyaXB0aW9uKCk7XG5cbiAgICB0aGlzLl9zdWJzY3JpcHRpb24uYWRkKHRoaXMubmF2U3RhcnQkLnN1YnNjcmliZSgpKTtcbiAgICB0aGlzLl9zdWJzY3JpcHRpb24uYWRkKHRoaXMucmVzRW5kJC5zdWJzY3JpYmUoKSk7XG4gICAgdGhpcy5fc3Vic2NyaXB0aW9uLmFkZCh0aGlzLm5hdkVuZCQuc3Vic2NyaWJlKCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgdXNlZCB0byBwcmV2ZW50IG1lbW9yeSBsZWFrcyB3aGVuIHRoZSByb290IHZpZXcgaXMgY3JlYXRlZCBhbmQgZGVzdHJveWVkIG11bHRpcGxlIHRpbWVzLFxuICAgKiBzaW5jZSBgc3Vic2NyaWJlYCBjYWxsYmFja3MgY2FwdHVyZSBgdGhpc2AgYW5kIHByZXZlbnQgbWFueSByZXNvdXJjZXMgZnJvbSBiZWluZyBHQydkLlxuICAgKi9cbiAgcHVibGljIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMuX3N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFdlIG9ubHkgX2F2b2lkXyBjcmVhdGluZyBhIG5hdmlnYXRpb24gcm9vdCBzcGFuIGluIG9uZSBjYXNlOlxuICAgKlxuICAgKiBUaGVyZSBpcyBhbiBvbmdvaW5nIHBhZ2Vsb2FkIHNwYW4gQU5EIHRoZSByb3V0ZXIgZGlkbid0IHlldCBlbWl0IHRoZSBmaXJzdCBuYXZpZ2F0aW9uIHN0YXJ0IGV2ZW50XG4gICAqXG4gICAqIFRoZSBmaXJzdCBuYXZpZ2F0aW9uIHN0YXJ0IGV2ZW50IHdpbGwgY3JlYXRlIHRoZSBjaGlsZCByb3V0aW5nIHNwYW5cbiAgICogYW5kIHVwZGF0ZSB0aGUgcGFnZWxvYWQgcm9vdCBzcGFuIG5hbWUgb24gUmVzb2x2ZUVuZC5cbiAgICpcbiAgICogVGhlcmUncyBhbiBlZGdlIGNhc2Ugd2UgbmVlZCB0byBhdm9pZCBoZXJlOiBJZiB0aGUgcm91dGVyIGZpcmVzIHRoZSBmaXJzdCBuYXZpZ2F0aW9uIHN0YXJ0IGV2ZW50XG4gICAqIF9hZnRlcl8gdGhlIHBhZ2Vsb2FkIHJvb3Qgc3BhbiBmaW5pc2hlZC4gVGhpcyBpcyB3aHkgd2UgY2hlY2sgZm9yIHRoZSBwYWdlbG9hZCByb290IHNwYW4uXG4gICAqIFBvc3NpYmxlIHJlYWwtd29ybGQgc2NlbmFyaW86IEFuZ3VsYXIgYXBwbGljYXRpb24gYW5kL29yIHJvdXRlciBpcyBib290c3RyYXBwZWQgYWZ0ZXIgdGhlIHBhZ2Vsb2FkXG4gICAqIGlkbGUgcm9vdCBzcGFuIGZpbmlzaGVkXG4gICAqXG4gICAqIFRoZSBvdmVyYWxsIHJhdGlvbmFsZSBpczpcbiAgICogLSBpZiB3ZSBhbHJlYWR5IGF2b2lkZWQgY3JlYXRpbmcgYSBuYXZpZ2F0aW9uIHJvb3Qgc3BhbiBvbmNlLCB3ZSBkb24ndCBhdm9pZCBpdCBhZ2FpblxuICAgKiAgIChpLmUuIHNldCBgX3BhZ2Vsb2FkT25nb2luZ2AgdG8gYGZhbHNlYClcbiAgICogLSBpZiBgX3BhZ2Vsb2FkT25nb2luZ2AgaXMgYWxyZWFkeSBgZmFsc2VgLCBjcmVhdGUgYSBuYXZpZ2F0aW9uIHJvb3Qgc3BhblxuICAgKiAtIGlmIHRoZXJlJ3Mgbm8gYWN0aXZlL3BhZ2Vsb2FkIHJvb3Qgc3BhbiwgY3JlYXRlIGEgbmF2aWdhdGlvbiByb290IHNwYW5cbiAgICogLSBvbmx5IGlmIHRoZXJlJ3MgYW4gb25nb2luZyBwYWdlbG9hZCByb290IHNwYW4gQU5EIGBfcGFnZWxvYWRPbmdvaW5nYCBpcyBzdGlsbCBgdHJ1ZSxcbiAgICogICBkb24ndCBjcmVhdGUgYSBuYXZpZ2F0aW9uIHJvb3Qgc3BhblxuICAgKi9cbiAgcHJpdmF0ZSBfaXNQYWdlbG9hZE9uZ29pbmcoKTogYm9vbGVhbiB7XG4gICAgaWYgKCF0aGlzLl9wYWdlbG9hZE9uZ29pbmcpIHtcbiAgICAgIC8vIHBhZ2Vsb2FkIGlzIGFscmVhZHkgZmluaXNoZWQsIG5vIG5lZWQgdG8gdXBkYXRlXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgYWN0aXZlU3BhbiA9IGdldEFjdGl2ZVNwYW4oKTtcbiAgICBpZiAoIWFjdGl2ZVNwYW4pIHtcbiAgICAgIHRoaXMuX3BhZ2Vsb2FkT25nb2luZyA9IGZhbHNlO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGNvbnN0IHJvb3RTcGFuID0gZ2V0Um9vdFNwYW4oYWN0aXZlU3Bhbik7XG5cbiAgICB0aGlzLl9wYWdlbG9hZE9uZ29pbmcgPSBzcGFuVG9KU09OKHJvb3RTcGFuKS5hdHRyaWJ1dGVzW1NFTlRSWV9PUF0gPT09ICdwYWdlbG9hZCc7XG4gICAgcmV0dXJuIHRoaXMuX3BhZ2Vsb2FkT25nb2luZztcbiAgfVxufVxuXG4vKipcbiAqIENhcHR1cmVzIHRoZSBpbml0aWFsaXphdGlvbiBsaWZlY3ljbGUgb2YgdGhlIGNvbXBvbmVudCB0aGlzIGRpcmVjdGl2ZSBpcyBhcHBsaWVkIHRvLlxuICogU3BlY2lmaWNhbGx5LCB0aGlzIGRpcmVjdGl2ZSBtZWFzdXJlcyB0aGUgdGltZSBiZXR3ZWVuIGBuZ09uSW5pdGAgYW5kIGBuZ0FmdGVyVmlld0luaXRgXG4gKiBvZiB0aGUgY29tcG9uZW50LlxuICpcbiAqIEZhbGxzIGJhY2sgdG8gdGhlIGNvbXBvbmVudCdzIHNlbGVjdG9yIGlmIG5vIG5hbWUgaXMgcHJvdmlkZWQuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYGh0bWxcbiAqIDxhcHAtbXktY29tcG9uZW50IHRyYWNlPVwibXlDb21wb25lbnRcIj48L2FwcC1teS1jb21wb25lbnQ+XG4gKiBgYGBcbiAqL1xuQERpcmVjdGl2ZSh7IHNlbGVjdG9yOiAnW3RyYWNlXScgfSlcbmV4cG9ydCBjbGFzcyBUcmFjZURpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XG4gIEBJbnB1dCgndHJhY2UnKSBwdWJsaWMgY29tcG9uZW50TmFtZT86IHN0cmluZztcblxuICBwcml2YXRlIF90cmFjaW5nU3Bhbj86IFNwYW47XG5cbiAgcHVibGljIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgX2hvc3Q6IEVsZW1lbnRSZWY8SFRNTEVsZW1lbnQ+KSB7fVxuXG4gIC8qKlxuICAgKiBJbXBsZW1lbnRhdGlvbiBvZiBPbkluaXQgbGlmZWN5Y2xlIG1ldGhvZFxuICAgKiBAaW5oZXJpdGRvY1xuICAgKi9cbiAgcHVibGljIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIGlmICghdGhpcy5jb21wb25lbnROYW1lKSB7XG4gICAgICAvLyBUZWNobmljYWxseSwgdGhlIGB0cmFjZWAgYmluZGluZyBzaG91bGQgYWx3YXlzIGJlIHByb3ZpZGVkLlxuICAgICAgLy8gSG93ZXZlciwgaWYgaXQgaXMgaW5jb3JyZWN0bHkgZGVjbGFyZWQgb24gdGhlIGVsZW1lbnQgd2l0aG91dCBhXG4gICAgICAvLyB2YWx1ZSAoZS5nLiwgYDxhcHAtY29tcG9uZW50IHRyYWNlIC8+YCksIHdlIGZhbGwgYmFjayB0byB1c2luZyBgdGFnTmFtZWBcbiAgICAgIC8vICh3aGljaCBpcyBlLmcuIGBBUFAtQ09NUE9ORU5UYCkuXG4gICAgICB0aGlzLmNvbXBvbmVudE5hbWUgPSB0aGlzLl9ob3N0Lm5hdGl2ZUVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIH1cblxuICAgIGlmIChnZXRBY3RpdmVTcGFuKCkpIHtcbiAgICAgIHRoaXMuX3RyYWNpbmdTcGFuID0gcnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT5cbiAgICAgICAgc3RhcnRJbmFjdGl2ZVNwYW4oe1xuICAgICAgICAgIG5hbWU6IGA8JHt0aGlzLmNvbXBvbmVudE5hbWV9PmAsXG4gICAgICAgICAgYXR0cmlidXRlczoge1xuICAgICAgICAgICAgW1NFTlRSWV9PUF06IFVJX01PVU5ULFxuICAgICAgICAgICAgW1NFTUFOVElDX0FUVFJJQlVURV9TRU5UUllfT1JJR0lOXTogJ2F1dG8udWkuYW5ndWxhci50cmFjZV9kaXJlY3RpdmUnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogSW1wbGVtZW50YXRpb24gb2YgQWZ0ZXJWaWV3SW5pdCBsaWZlY3ljbGUgbWV0aG9kXG4gICAqIEBpbmhlcml0ZG9jXG4gICAqL1xuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgIGNvbnN0IHNwYW4gPSB0aGlzLl90cmFjaW5nU3BhbjtcbiAgICBpZiAoc3Bhbikge1xuICAgICAgcnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4gc3Bhbi5lbmQoKSk7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQSBtb2R1bGUgc2VydmVzIGFzIGEgc2luZ2xlIGNvbXBpbGF0aW9uIHVuaXQgZm9yIHRoZSBgVHJhY2VEaXJlY3RpdmVgIGFuZCBjYW4gYmUgcmUtdXNlZCBieSBhbnkgb3RoZXIgbW9kdWxlLlxuICovXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtUcmFjZURpcmVjdGl2ZV0sXG4gIGV4cG9ydHM6IFtUcmFjZURpcmVjdGl2ZV0sXG59KVxuZXhwb3J0IGNsYXNzIFRyYWNlTW9kdWxlIHt9XG5cbmludGVyZmFjZSBUcmFjZUNsYXNzT3B0aW9ucyB7XG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSBjbGFzc1xuICAgKi9cbiAgbmFtZT86IHN0cmluZztcbn1cblxuLyoqXG4gKiBEZWNvcmF0b3IgZnVuY3Rpb24gdGhhdCBjYW4gYmUgdXNlZCB0byBjYXB0dXJlIGluaXRpYWxpemF0aW9uIGxpZmVjeWNsZSBvZiB0aGUgd2hvbGUgY29tcG9uZW50LlxuICovXG5leHBvcnQgZnVuY3Rpb24gVHJhY2VDbGFzcyhvcHRpb25zPzogVHJhY2VDbGFzc09wdGlvbnMpOiBDbGFzc0RlY29yYXRvciB7XG4gIGxldCB0cmFjaW5nU3BhbjogU3BhbjtcblxuICAvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLW1lbWJlci1hY2Nlc3MgKi9cbiAgcmV0dXJuIHRhcmdldCA9PiB7XG4gICAgY29uc3Qgb3JpZ2luYWxPbkluaXQgPSB0YXJnZXQucHJvdG90eXBlLm5nT25Jbml0O1xuICAgIHRhcmdldC5wcm90b3R5cGUubmdPbkluaXQgPSBmdW5jdGlvbiAoLi4uYXJnczogdW5rbm93bltdKTogUmV0dXJuVHlwZTx0eXBlb2Ygb3JpZ2luYWxPbkluaXQ+IHtcbiAgICAgIHRyYWNpbmdTcGFuID0gcnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT5cbiAgICAgICAgc3RhcnRJbmFjdGl2ZVNwYW4oe1xuICAgICAgICAgIG9ubHlJZlBhcmVudDogdHJ1ZSxcbiAgICAgICAgICBuYW1lOiBgPCR7b3B0aW9ucz8ubmFtZSB8fCAndW5uYW1lZCd9PmAsXG4gICAgICAgICAgYXR0cmlidXRlczoge1xuICAgICAgICAgICAgW1NFTlRSWV9PUF06IFVJX01PVU5ULFxuICAgICAgICAgICAgW1NFTUFOVElDX0FUVFJJQlVURV9TRU5UUllfT1JJR0lOXTogJ2F1dG8udWkuYW5ndWxhci50cmFjZV9jbGFzc19kZWNvcmF0b3InLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgKTtcblxuICAgICAgaWYgKG9yaWdpbmFsT25Jbml0KSB7XG4gICAgICAgIHJldHVybiBvcmlnaW5hbE9uSW5pdC5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgb3JpZ2luYWxBZnRlclZpZXdJbml0ID0gdGFyZ2V0LnByb3RvdHlwZS5uZ0FmdGVyVmlld0luaXQ7XG4gICAgdGFyZ2V0LnByb3RvdHlwZS5uZ0FmdGVyVmlld0luaXQgPSBmdW5jdGlvbiAoLi4uYXJnczogdW5rbm93bltdKTogUmV0dXJuVHlwZTx0eXBlb2Ygb3JpZ2luYWxBZnRlclZpZXdJbml0PiB7XG4gICAgICBpZiAodHJhY2luZ1NwYW4pIHtcbiAgICAgICAgcnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4gdHJhY2luZ1NwYW4uZW5kKCkpO1xuICAgICAgfVxuICAgICAgaWYgKG9yaWdpbmFsQWZ0ZXJWaWV3SW5pdCkge1xuICAgICAgICByZXR1cm4gb3JpZ2luYWxBZnRlclZpZXdJbml0LmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgfVxuICAgIH07XG4gIH07XG4gIC8qIGVzbGludC1lbmFibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVuc2FmZS1tZW1iZXItYWNjZXNzICovXG59XG5cbmludGVyZmFjZSBUcmFjZU1ldGhvZE9wdGlvbnMge1xuICAvKipcbiAgICogTmFtZSBvZiB0aGUgbWV0aG9kIChpcyBhZGRlZCB0byB0aGUgdHJhY2luZyBzcGFuKVxuICAgKi9cbiAgbmFtZT86IHN0cmluZztcbn1cblxuLyoqXG4gKiBEZWNvcmF0b3IgZnVuY3Rpb24gdGhhdCBjYW4gYmUgdXNlZCB0byBjYXB0dXJlIGEgc2luZ2xlIGxpZmVjeWNsZSBtZXRob2RzIG9mIHRoZSBjb21wb25lbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBUcmFjZU1ldGhvZChvcHRpb25zPzogVHJhY2VNZXRob2RPcHRpb25zKTogTWV0aG9kRGVjb3JhdG9yIHtcbiAgcmV0dXJuIChfdGFyZ2V0OiB1bmtub3duLCBwcm9wZXJ0eUtleTogc3RyaW5nIHwgc3ltYm9sLCBkZXNjcmlwdG9yOiBQcm9wZXJ0eURlc2NyaXB0b3IpID0+IHtcbiAgICBjb25zdCBvcmlnaW5hbE1ldGhvZCA9IGRlc2NyaXB0b3IudmFsdWU7XG4gICAgZGVzY3JpcHRvci52YWx1ZSA9IGZ1bmN0aW9uICguLi5hcmdzOiB1bmtub3duW10pOiBSZXR1cm5UeXBlPHR5cGVvZiBvcmlnaW5hbE1ldGhvZD4ge1xuICAgICAgY29uc3Qgbm93ID0gdGltZXN0YW1wSW5TZWNvbmRzKCk7XG5cbiAgICAgIHJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgICAgc3RhcnRJbmFjdGl2ZVNwYW4oe1xuICAgICAgICAgIG9ubHlJZlBhcmVudDogdHJ1ZSxcbiAgICAgICAgICBuYW1lOiBgPCR7b3B0aW9ucz8ubmFtZSA/IG9wdGlvbnMubmFtZSA6ICd1bm5hbWVkJ30+YCxcbiAgICAgICAgICBzdGFydFRpbWU6IG5vdyxcbiAgICAgICAgICBhdHRyaWJ1dGVzOiB7XG4gICAgICAgICAgICBbU0VOVFJZX09QXTogRlVOQ1RJT04sXG4gICAgICAgICAgICBbU0VNQU5USUNfQVRUUklCVVRFX1NFTlRSWV9PUklHSU5dOiAnYXV0by51aS5hbmd1bGFyLnRyYWNlX21ldGhvZF9kZWNvcmF0b3InLFxuICAgICAgICAgICAgW0NPREVfRlVOQ1RJT05fTkFNRV06IFN0cmluZyhwcm9wZXJ0eUtleSksXG4gICAgICAgICAgfSxcbiAgICAgICAgfSkuZW5kKG5vdyk7XG4gICAgICB9KTtcblxuICAgICAgaWYgKG9yaWdpbmFsTWV0aG9kKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW5zYWZlLW1lbWJlci1hY2Nlc3NcbiAgICAgICAgcmV0dXJuIG9yaWdpbmFsTWV0aG9kLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIGRlc2NyaXB0b3I7XG4gIH07XG59XG5cbi8qKlxuICogVGFrZXMgdGhlIHBhcmFtZXRlcml6ZWQgcm91dGUgZnJvbSBhIGdpdmVuIEFjdGl2YXRlZFJvdXRlU25hcHNob3QgYW5kIGNvbmNhdGVuYXRlcyB0aGUgc25hcHNob3Qnc1xuICogY2hpbGQgcm91dGUgd2l0aCBpdHMgcGFyZW50IHRvIHByb2R1Y2UgdGhlIGNvbXBsZXRlIHBhcmFtZXRlcml6ZWQgVVJMIG9mIHRoZSBhY3RpdmF0ZWQgcm91dGUuXG4gKiBUaGlzIGhhcHBlbnMgcmVjdXJzaXZlbHkgdW50aWwgdGhlIGxhc3QgY2hpbGQgKGkuZS4gdGhlIGVuZCBvZiB0aGUgVVJMKSBpcyByZWFjaGVkLlxuICpcbiAqIEBwYXJhbSByb3V0ZSB0aGUgQWN0aXZhdGVkUm91dGVTbmFwc2hvdCBvZiB3aGljaCBpdHMgcGF0aCBhbmQgaXRzIGNoaWxkJ3MgcGF0aCBpcyBjb25jYXRlbmF0ZWRcbiAqXG4gKiBAcmV0dXJucyB0aGUgY29uY2F0ZW5hdGVkIHBhcmFtZXRlcml6ZWQgcm91dGUgc3RyaW5nXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRQYXJhbWV0ZXJpemVkUm91dGVGcm9tU25hcHNob3Qocm91dGU/OiBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90IHwgbnVsbCk6IHN0cmluZyB7XG4gIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuXG4gIGxldCBjdXJyZW50Um91dGUgPSByb3V0ZT8uZmlyc3RDaGlsZDtcbiAgd2hpbGUgKGN1cnJlbnRSb3V0ZSkge1xuICAgIGNvbnN0IHBhdGggPSBjdXJyZW50Um91dGU/LnJvdXRlQ29uZmlnICYmIGN1cnJlbnRSb3V0ZS5yb3V0ZUNvbmZpZy5wYXRoO1xuICAgIGlmIChwYXRoID09PSBudWxsIHx8IHBhdGggPT09IHVuZGVmaW5lZCkge1xuICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgcGFydHMucHVzaChwYXRoKTtcbiAgICBjdXJyZW50Um91dGUgPSBjdXJyZW50Um91dGUuZmlyc3RDaGlsZDtcbiAgfVxuXG4gIGNvbnN0IGZ1bGxQYXRoID0gcGFydHMuZmlsdGVyKHBhcnQgPT4gcGFydCkuam9pbignLycpO1xuICByZXR1cm4gZnVsbFBhdGggPyBgLyR7ZnVsbFBhdGh9L2AgOiAnLyc7XG59XG4iXX0=