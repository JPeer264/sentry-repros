import { HttpErrorResponse } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import * as Sentry from '@sentry/browser';
import { consoleSandbox, isString } from '@sentry/core';
import { runOutsideAngular } from './zone';
import * as i0 from "@angular/core";
// https://github.com/angular/angular/blob/master/packages/core/src/util/errors.ts
function tryToUnwrapZonejsError(error) {
    // TODO: once Angular14 is the minimum requirement ERROR_ORIGINAL_ERROR and
    //  getOriginalError from error.ts can be used directly.
    return error?.ngOriginalError
        ? error.ngOriginalError
        : error;
}
function extractHttpModuleError(error) {
    // The `error` property of http exception can be either an `Error` object, which we can use directly...
    if (isErrorOrErrorLikeObject(error.error)) {
        return error.error;
    }
    // ... or an`ErrorEvent`, which can provide us with the message but no stack...
    // guarding `ErrorEvent` against `undefined` as it's not defined in Node environments
    // oxlint-disable-next-line typescript/prefer-optional-chain
    if (typeof ErrorEvent !== 'undefined' && error.error instanceof ErrorEvent && error.error.message) {
        return error.error.message;
    }
    // ...or the request body itself, which we can use as a message instead.
    if (typeof error.error === 'string') {
        return `Server returned code ${error.status} with body "${error.error}"`;
    }
    // If we don't have any detailed information, fallback to the request message itself.
    return error.message;
}
function isErrorOrErrorLikeObject(value) {
    if (value instanceof Error) {
        return true;
    }
    if (value === null || typeof value !== 'object') {
        return false;
    }
    const candidate = value;
    return (isString(candidate.name) &&
        isString(candidate.message) &&
        (undefined === candidate.stack || isString(candidate.stack)));
}
/**
 * Implementation of Angular's ErrorHandler provider that can be used as a drop-in replacement for the stock one.
 */
class SentryErrorHandler {
    constructor(options) {
        this._options = {
            logErrors: true,
            ...options,
        };
    }
    /**
     * Method executed when the injector is destroyed.
     */
    ngOnDestroy() {
        if (this._removeAfterSendEventListener) {
            this._removeAfterSendEventListener();
        }
    }
    /**
     * Method called for every value captured through the ErrorHandler
     */
    handleError(error) {
        const extractedError = this._extractError(error) || 'Handled unknown error';
        // Capture handled exception and send it to Sentry.
        const eventId = runOutsideAngular(() => Sentry.captureException(extractedError, {
            mechanism: { type: 'auto.function.angular.error_handler', handled: false },
        }));
        // When in development mode, log the error to console for immediate feedback.
        if (this._options.logErrors) {
            // eslint-disable-next-line no-console
            consoleSandbox(() => console.error(extractedError));
        }
        // Optionally show user dialog to provide details on what happened.
        if (this._options.showDialog) {
            const client = Sentry.getClient();
            if (client && !this._removeAfterSendEventListener) {
                this._removeAfterSendEventListener = client.on('afterSendEvent', (event) => {
                    if (!event.type && event.event_id) {
                        runOutsideAngular(() => {
                            Sentry.showReportDialog({ ...this._options.dialogOptions, eventId: event.event_id });
                        });
                    }
                });
            }
            else if (!client) {
                runOutsideAngular(() => {
                    Sentry.showReportDialog({ ...this._options.dialogOptions, eventId });
                });
            }
        }
    }
    /**
     * Used to pull a desired value that will be used to capture an event out of the raw value captured by ErrorHandler.
     */
    _extractError(error) {
        // Allow custom overrides of extracting function
        if (this._options.extractor) {
            const defaultExtractor = this._defaultExtractor.bind(this);
            return this._options.extractor(error, defaultExtractor);
        }
        return this._defaultExtractor(error);
    }
    /**
     * Default implementation of error extraction that handles default error wrapping, HTTP responses, ErrorEvent and few other known cases.
     */
    _defaultExtractor(errorCandidate) {
        const error = tryToUnwrapZonejsError(errorCandidate);
        // If it's http module error, extract as much information from it as we can.
        if (error instanceof HttpErrorResponse) {
            return extractHttpModuleError(error);
        }
        // We can handle messages and Error objects directly.
        if (typeof error === 'string' || isErrorOrErrorLikeObject(error)) {
            return error;
        }
        // Nothing was extracted, fallback to default error message.
        return null;
    }
}
SentryErrorHandler.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: SentryErrorHandler, deps: [{ token: 'errorHandlerOptions' }], target: i0.ɵɵFactoryTarget.Injectable });
SentryErrorHandler.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: SentryErrorHandler, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: SentryErrorHandler, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: ['errorHandlerOptions']
                }] }]; } });
/**
 * Factory function that creates an instance of a preconfigured ErrorHandler provider.
 */
function createErrorHandler(config) {
    return new SentryErrorHandler(config);
}
export { createErrorHandler, SentryErrorHandler };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3JoYW5kbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2Vycm9yaGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUV6RCxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUVuRCxPQUFPLEtBQUssTUFBTSxNQUFNLGlCQUFpQixDQUFDO0FBRTFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsUUFBUSxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ3hELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLFFBQVEsQ0FBQzs7QUFpQjNDLGtGQUFrRjtBQUNsRixTQUFTLHNCQUFzQixDQUFDLEtBQWM7SUFDNUMsMkVBQTJFO0lBQzNFLHdEQUF3RDtJQUN4RCxPQUFRLEtBQXFDLEVBQUUsZUFBZTtRQUM1RCxDQUFDLENBQUUsS0FBb0MsQ0FBQyxlQUFlO1FBQ3ZELENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDWixDQUFDO0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxLQUF3QjtJQUN0RCx1R0FBdUc7SUFDdkcsSUFBSSx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7UUFDekMsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDO0tBQ3BCO0lBRUQsK0VBQStFO0lBQy9FLHFGQUFxRjtJQUNyRiw0REFBNEQ7SUFDNUQsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksS0FBSyxDQUFDLEtBQUssWUFBWSxVQUFVLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUU7UUFDakcsT0FBTyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztLQUM1QjtJQUVELHdFQUF3RTtJQUN4RSxJQUFJLE9BQU8sS0FBSyxDQUFDLEtBQUssS0FBSyxRQUFRLEVBQUU7UUFDbkMsT0FBTyx3QkFBd0IsS0FBSyxDQUFDLE1BQU0sZUFBZSxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUM7S0FDMUU7SUFFRCxxRkFBcUY7SUFDckYsT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ3ZCLENBQUM7QUFRRCxTQUFTLHdCQUF3QixDQUFDLEtBQWM7SUFDOUMsSUFBSSxLQUFLLFlBQVksS0FBSyxFQUFFO1FBQzFCLE9BQU8sSUFBSSxDQUFDO0tBQ2I7SUFFRCxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO1FBQy9DLE9BQU8sS0FBSyxDQUFDO0tBQ2Q7SUFFRCxNQUFNLFNBQVMsR0FBRyxLQUF1QixDQUFDO0lBRTFDLE9BQU8sQ0FDTCxRQUFRLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztRQUN4QixRQUFRLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztRQUMzQixDQUFDLFNBQVMsS0FBSyxTQUFTLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FDN0QsQ0FBQztBQUNKLENBQUM7QUFFRDs7R0FFRztBQUNILE1BQ00sa0JBQWtCO0lBTXRCLFlBQWtELE9BQTZCO1FBQzdFLElBQUksQ0FBQyxRQUFRLEdBQUc7WUFDZCxTQUFTLEVBQUUsSUFBSTtZQUNmLEdBQUcsT0FBTztTQUNYLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSSxXQUFXO1FBQ2hCLElBQUksSUFBSSxDQUFDLDZCQUE2QixFQUFFO1lBQ3RDLElBQUksQ0FBQyw2QkFBNkIsRUFBRSxDQUFDO1NBQ3RDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksV0FBVyxDQUFDLEtBQWM7UUFDL0IsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsSUFBSSx1QkFBdUIsQ0FBQztRQUU1RSxtREFBbUQ7UUFDbkQsTUFBTSxPQUFPLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQ3JDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLEVBQUU7WUFDdEMsU0FBUyxFQUFFLEVBQUUsSUFBSSxFQUFFLHFDQUFxQyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7U0FDM0UsQ0FBQyxDQUNILENBQUM7UUFFRiw2RUFBNkU7UUFDN0UsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtZQUMzQixzQ0FBc0M7WUFDdEMsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztTQUNyRDtRQUVELG1FQUFtRTtRQUNuRSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO1lBQzVCLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUVsQyxJQUFJLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsRUFBRTtnQkFDakQsSUFBSSxDQUFDLDZCQUE2QixHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxLQUFZLEVBQUUsRUFBRTtvQkFDaEYsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRTt3QkFDakMsaUJBQWlCLENBQUMsR0FBRyxFQUFFOzRCQUNyQixNQUFNLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBRSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQzt3QkFDdkYsQ0FBQyxDQUFDLENBQUM7cUJBQ0o7Z0JBQ0gsQ0FBQyxDQUFDLENBQUM7YUFDSjtpQkFBTSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNsQixpQkFBaUIsQ0FBQyxHQUFHLEVBQUU7b0JBQ3JCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztnQkFDdkUsQ0FBQyxDQUFDLENBQUM7YUFDSjtTQUNGO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ08sYUFBYSxDQUFDLEtBQWM7UUFDcEMsZ0RBQWdEO1FBQ2hELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7WUFDM0IsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzNELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDLENBQUM7U0FDekQ7UUFFRCxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7O09BRUc7SUFDTyxpQkFBaUIsQ0FBQyxjQUF1QjtRQUNqRCxNQUFNLEtBQUssR0FBRyxzQkFBc0IsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUVyRCw0RUFBNEU7UUFDNUUsSUFBSSxLQUFLLFlBQVksaUJBQWlCLEVBQUU7WUFDdEMsT0FBTyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUN0QztRQUVELHFEQUFxRDtRQUNyRCxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNoRSxPQUFPLEtBQUssQ0FBQztTQUNkO1FBRUQsNERBQTREO1FBQzVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQzs7K0dBNUZHLGtCQUFrQixrQkFNSyxxQkFBcUI7bUhBTjVDLGtCQUFrQixjQURFLE1BQU07MkZBQzFCLGtCQUFrQjtrQkFEdkIsVUFBVTttQkFBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUU7OzBCQU9aLE1BQU07MkJBQUMscUJBQXFCOztBQXlGbEQ7O0dBRUc7QUFDSCxTQUFTLGtCQUFrQixDQUFDLE1BQTRCO0lBQ3RELE9BQU8sSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN4QyxDQUFDO0FBRUQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLGtCQUFrQixFQUFFLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB0eXBlIHsgRXJyb3JIYW5kbGVyIGFzIEFuZ3VsYXJFcnJvckhhbmRsZXIsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgdHlwZSB7IFJlcG9ydERpYWxvZ09wdGlvbnMgfSBmcm9tICdAc2VudHJ5L2Jyb3dzZXInO1xuaW1wb3J0ICogYXMgU2VudHJ5IGZyb20gJ0BzZW50cnkvYnJvd3Nlcic7XG5pbXBvcnQgdHlwZSB7IEV2ZW50IH0gZnJvbSAnQHNlbnRyeS9jb3JlJztcbmltcG9ydCB7IGNvbnNvbGVTYW5kYm94LCBpc1N0cmluZyB9IGZyb20gJ0BzZW50cnkvY29yZSc7XG5pbXBvcnQgeyBydW5PdXRzaWRlQW5ndWxhciB9IGZyb20gJy4vem9uZSc7XG5cbi8qKlxuICogT3B0aW9ucyB1c2VkIHRvIGNvbmZpZ3VyZSB0aGUgYmVoYXZpb3Igb2YgdGhlIEFuZ3VsYXIgRXJyb3JIYW5kbGVyLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEVycm9ySGFuZGxlck9wdGlvbnMge1xuICBsb2dFcnJvcnM/OiBib29sZWFuO1xuICBzaG93RGlhbG9nPzogYm9vbGVhbjtcbiAgZGlhbG9nT3B0aW9ucz86IFJlcG9ydERpYWxvZ09wdGlvbnM7XG4gIC8qKlxuICAgKiBDdXN0b20gaW1wbGVtZW50YXRpb24gb2YgZXJyb3IgZXh0cmFjdGlvbiBmcm9tIHRoZSByYXcgdmFsdWUgY2FwdHVyZWQgYnkgdGhlIEFuZ3VsYXIuXG4gICAqIEBwYXJhbSBlcnJvciBWYWx1ZSBjYXB0dXJlZCBieSBBbmd1bGFyJ3MgRXJyb3JIYW5kbGVyIHByb3ZpZGVyXG4gICAqIEBwYXJhbSBkZWZhdWx0RXh0cmFjdG9yIERlZmF1bHQgaW1wbGVtZW50YXRpb24gdGhhdCBjYW4gYmUgdXNlZCBhcyB0aGUgZmFsbGJhY2sgaW4gY2FzZSBvZiBjdXN0b20gaW1wbGVtZW50YXRpb25cbiAgICovXG4gIGV4dHJhY3Rvcj8oZXJyb3I6IHVua25vd24sIGRlZmF1bHRFeHRyYWN0b3I6IChlcnJvcjogdW5rbm93bikgPT4gdW5rbm93bik6IHVua25vd247XG59XG5cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi9tYXN0ZXIvcGFja2FnZXMvY29yZS9zcmMvdXRpbC9lcnJvcnMudHNcbmZ1bmN0aW9uIHRyeVRvVW53cmFwWm9uZWpzRXJyb3IoZXJyb3I6IHVua25vd24pOiB1bmtub3duIHwgRXJyb3Ige1xuICAvLyBUT0RPOiBvbmNlIEFuZ3VsYXIxNCBpcyB0aGUgbWluaW11bSByZXF1aXJlbWVudCBFUlJPUl9PUklHSU5BTF9FUlJPUiBhbmRcbiAgLy8gIGdldE9yaWdpbmFsRXJyb3IgZnJvbSBlcnJvci50cyBjYW4gYmUgdXNlZCBkaXJlY3RseS5cbiAgcmV0dXJuIChlcnJvciBhcyB7IG5nT3JpZ2luYWxFcnJvcj86IEVycm9yIH0pPy5uZ09yaWdpbmFsRXJyb3JcbiAgICA/IChlcnJvciBhcyB7IG5nT3JpZ2luYWxFcnJvcjogRXJyb3IgfSkubmdPcmlnaW5hbEVycm9yXG4gICAgOiBlcnJvcjtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdEh0dHBNb2R1bGVFcnJvcihlcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpOiBzdHJpbmcgfCBFcnJvciB7XG4gIC8vIFRoZSBgZXJyb3JgIHByb3BlcnR5IG9mIGh0dHAgZXhjZXB0aW9uIGNhbiBiZSBlaXRoZXIgYW4gYEVycm9yYCBvYmplY3QsIHdoaWNoIHdlIGNhbiB1c2UgZGlyZWN0bHkuLi5cbiAgaWYgKGlzRXJyb3JPckVycm9yTGlrZU9iamVjdChlcnJvci5lcnJvcikpIHtcbiAgICByZXR1cm4gZXJyb3IuZXJyb3I7XG4gIH1cblxuICAvLyAuLi4gb3IgYW5gRXJyb3JFdmVudGAsIHdoaWNoIGNhbiBwcm92aWRlIHVzIHdpdGggdGhlIG1lc3NhZ2UgYnV0IG5vIHN0YWNrLi4uXG4gIC8vIGd1YXJkaW5nIGBFcnJvckV2ZW50YCBhZ2FpbnN0IGB1bmRlZmluZWRgIGFzIGl0J3Mgbm90IGRlZmluZWQgaW4gTm9kZSBlbnZpcm9ubWVudHNcbiAgLy8gb3hsaW50LWRpc2FibGUtbmV4dC1saW5lIHR5cGVzY3JpcHQvcHJlZmVyLW9wdGlvbmFsLWNoYWluXG4gIGlmICh0eXBlb2YgRXJyb3JFdmVudCAhPT0gJ3VuZGVmaW5lZCcgJiYgZXJyb3IuZXJyb3IgaW5zdGFuY2VvZiBFcnJvckV2ZW50ICYmIGVycm9yLmVycm9yLm1lc3NhZ2UpIHtcbiAgICByZXR1cm4gZXJyb3IuZXJyb3IubWVzc2FnZTtcbiAgfVxuXG4gIC8vIC4uLm9yIHRoZSByZXF1ZXN0IGJvZHkgaXRzZWxmLCB3aGljaCB3ZSBjYW4gdXNlIGFzIGEgbWVzc2FnZSBpbnN0ZWFkLlxuICBpZiAodHlwZW9mIGVycm9yLmVycm9yID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBgU2VydmVyIHJldHVybmVkIGNvZGUgJHtlcnJvci5zdGF0dXN9IHdpdGggYm9keSBcIiR7ZXJyb3IuZXJyb3J9XCJgO1xuICB9XG5cbiAgLy8gSWYgd2UgZG9uJ3QgaGF2ZSBhbnkgZGV0YWlsZWQgaW5mb3JtYXRpb24sIGZhbGxiYWNrIHRvIHRoZSByZXF1ZXN0IG1lc3NhZ2UgaXRzZWxmLlxuICByZXR1cm4gZXJyb3IubWVzc2FnZTtcbn1cblxudHlwZSBFcnJvckNhbmRpZGF0ZSA9IHtcbiAgbmFtZT86IHVua25vd247XG4gIG1lc3NhZ2U/OiB1bmtub3duO1xuICBzdGFjaz86IHVua25vd247XG59O1xuXG5mdW5jdGlvbiBpc0Vycm9yT3JFcnJvckxpa2VPYmplY3QodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBFcnJvciB7XG4gIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBpZiAodmFsdWUgPT09IG51bGwgfHwgdHlwZW9mIHZhbHVlICE9PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IGNhbmRpZGF0ZSA9IHZhbHVlIGFzIEVycm9yQ2FuZGlkYXRlO1xuXG4gIHJldHVybiAoXG4gICAgaXNTdHJpbmcoY2FuZGlkYXRlLm5hbWUpICYmXG4gICAgaXNTdHJpbmcoY2FuZGlkYXRlLm1lc3NhZ2UpICYmXG4gICAgKHVuZGVmaW5lZCA9PT0gY2FuZGlkYXRlLnN0YWNrIHx8IGlzU3RyaW5nKGNhbmRpZGF0ZS5zdGFjaykpXG4gICk7XG59XG5cbi8qKlxuICogSW1wbGVtZW50YXRpb24gb2YgQW5ndWxhcidzIEVycm9ySGFuZGxlciBwcm92aWRlciB0aGF0IGNhbiBiZSB1c2VkIGFzIGEgZHJvcC1pbiByZXBsYWNlbWVudCBmb3IgdGhlIHN0b2NrIG9uZS5cbiAqL1xuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmNsYXNzIFNlbnRyeUVycm9ySGFuZGxlciBpbXBsZW1lbnRzIEFuZ3VsYXJFcnJvckhhbmRsZXIsIE9uRGVzdHJveSB7XG4gIHByb3RlY3RlZCByZWFkb25seSBfb3B0aW9uczogRXJyb3JIYW5kbGVyT3B0aW9ucztcblxuICAvKiogVGhlIGNsZWFudXAgZnVuY3Rpb24gaXMgZXhlY3V0ZWQgd2hlbiB0aGUgaW5qZWN0b3IgaXMgZGVzdHJveWVkLiAqL1xuICBwcml2YXRlIF9yZW1vdmVBZnRlclNlbmRFdmVudExpc3RlbmVyPzogKCkgPT4gdm9pZDtcblxuICBwdWJsaWMgY29uc3RydWN0b3IoQEluamVjdCgnZXJyb3JIYW5kbGVyT3B0aW9ucycpIG9wdGlvbnM/OiBFcnJvckhhbmRsZXJPcHRpb25zKSB7XG4gICAgdGhpcy5fb3B0aW9ucyA9IHtcbiAgICAgIGxvZ0Vycm9yczogdHJ1ZSxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNZXRob2QgZXhlY3V0ZWQgd2hlbiB0aGUgaW5qZWN0b3IgaXMgZGVzdHJveWVkLlxuICAgKi9cbiAgcHVibGljIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIGlmICh0aGlzLl9yZW1vdmVBZnRlclNlbmRFdmVudExpc3RlbmVyKSB7XG4gICAgICB0aGlzLl9yZW1vdmVBZnRlclNlbmRFdmVudExpc3RlbmVyKCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIE1ldGhvZCBjYWxsZWQgZm9yIGV2ZXJ5IHZhbHVlIGNhcHR1cmVkIHRocm91Z2ggdGhlIEVycm9ySGFuZGxlclxuICAgKi9cbiAgcHVibGljIGhhbmRsZUVycm9yKGVycm9yOiB1bmtub3duKTogdm9pZCB7XG4gICAgY29uc3QgZXh0cmFjdGVkRXJyb3IgPSB0aGlzLl9leHRyYWN0RXJyb3IoZXJyb3IpIHx8ICdIYW5kbGVkIHVua25vd24gZXJyb3InO1xuXG4gICAgLy8gQ2FwdHVyZSBoYW5kbGVkIGV4Y2VwdGlvbiBhbmQgc2VuZCBpdCB0byBTZW50cnkuXG4gICAgY29uc3QgZXZlbnRJZCA9IHJ1bk91dHNpZGVBbmd1bGFyKCgpID0+XG4gICAgICBTZW50cnkuY2FwdHVyZUV4Y2VwdGlvbihleHRyYWN0ZWRFcnJvciwge1xuICAgICAgICBtZWNoYW5pc206IHsgdHlwZTogJ2F1dG8uZnVuY3Rpb24uYW5ndWxhci5lcnJvcl9oYW5kbGVyJywgaGFuZGxlZDogZmFsc2UgfSxcbiAgICAgIH0pLFxuICAgICk7XG5cbiAgICAvLyBXaGVuIGluIGRldmVsb3BtZW50IG1vZGUsIGxvZyB0aGUgZXJyb3IgdG8gY29uc29sZSBmb3IgaW1tZWRpYXRlIGZlZWRiYWNrLlxuICAgIGlmICh0aGlzLl9vcHRpb25zLmxvZ0Vycm9ycykge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGVTYW5kYm94KCgpID0+IGNvbnNvbGUuZXJyb3IoZXh0cmFjdGVkRXJyb3IpKTtcbiAgICB9XG5cbiAgICAvLyBPcHRpb25hbGx5IHNob3cgdXNlciBkaWFsb2cgdG8gcHJvdmlkZSBkZXRhaWxzIG9uIHdoYXQgaGFwcGVuZWQuXG4gICAgaWYgKHRoaXMuX29wdGlvbnMuc2hvd0RpYWxvZykge1xuICAgICAgY29uc3QgY2xpZW50ID0gU2VudHJ5LmdldENsaWVudCgpO1xuXG4gICAgICBpZiAoY2xpZW50ICYmICF0aGlzLl9yZW1vdmVBZnRlclNlbmRFdmVudExpc3RlbmVyKSB7XG4gICAgICAgIHRoaXMuX3JlbW92ZUFmdGVyU2VuZEV2ZW50TGlzdGVuZXIgPSBjbGllbnQub24oJ2FmdGVyU2VuZEV2ZW50JywgKGV2ZW50OiBFdmVudCkgPT4ge1xuICAgICAgICAgIGlmICghZXZlbnQudHlwZSAmJiBldmVudC5ldmVudF9pZCkge1xuICAgICAgICAgICAgcnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgICAgICAgICBTZW50cnkuc2hvd1JlcG9ydERpYWxvZyh7IC4uLnRoaXMuX29wdGlvbnMuZGlhbG9nT3B0aW9ucywgZXZlbnRJZDogZXZlbnQuZXZlbnRfaWQgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmICghY2xpZW50KSB7XG4gICAgICAgIHJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgICAgICBTZW50cnkuc2hvd1JlcG9ydERpYWxvZyh7IC4uLnRoaXMuX29wdGlvbnMuZGlhbG9nT3B0aW9ucywgZXZlbnRJZCB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVzZWQgdG8gcHVsbCBhIGRlc2lyZWQgdmFsdWUgdGhhdCB3aWxsIGJlIHVzZWQgdG8gY2FwdHVyZSBhbiBldmVudCBvdXQgb2YgdGhlIHJhdyB2YWx1ZSBjYXB0dXJlZCBieSBFcnJvckhhbmRsZXIuXG4gICAqL1xuICBwcm90ZWN0ZWQgX2V4dHJhY3RFcnJvcihlcnJvcjogdW5rbm93bik6IHVua25vd24ge1xuICAgIC8vIEFsbG93IGN1c3RvbSBvdmVycmlkZXMgb2YgZXh0cmFjdGluZyBmdW5jdGlvblxuICAgIGlmICh0aGlzLl9vcHRpb25zLmV4dHJhY3Rvcikge1xuICAgICAgY29uc3QgZGVmYXVsdEV4dHJhY3RvciA9IHRoaXMuX2RlZmF1bHRFeHRyYWN0b3IuYmluZCh0aGlzKTtcbiAgICAgIHJldHVybiB0aGlzLl9vcHRpb25zLmV4dHJhY3RvcihlcnJvciwgZGVmYXVsdEV4dHJhY3Rvcik7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX2RlZmF1bHRFeHRyYWN0b3IoZXJyb3IpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmF1bHQgaW1wbGVtZW50YXRpb24gb2YgZXJyb3IgZXh0cmFjdGlvbiB0aGF0IGhhbmRsZXMgZGVmYXVsdCBlcnJvciB3cmFwcGluZywgSFRUUCByZXNwb25zZXMsIEVycm9yRXZlbnQgYW5kIGZldyBvdGhlciBrbm93biBjYXNlcy5cbiAgICovXG4gIHByb3RlY3RlZCBfZGVmYXVsdEV4dHJhY3RvcihlcnJvckNhbmRpZGF0ZTogdW5rbm93bik6IHVua25vd24ge1xuICAgIGNvbnN0IGVycm9yID0gdHJ5VG9VbndyYXBab25lanNFcnJvcihlcnJvckNhbmRpZGF0ZSk7XG5cbiAgICAvLyBJZiBpdCdzIGh0dHAgbW9kdWxlIGVycm9yLCBleHRyYWN0IGFzIG11Y2ggaW5mb3JtYXRpb24gZnJvbSBpdCBhcyB3ZSBjYW4uXG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgSHR0cEVycm9yUmVzcG9uc2UpIHtcbiAgICAgIHJldHVybiBleHRyYWN0SHR0cE1vZHVsZUVycm9yKGVycm9yKTtcbiAgICB9XG5cbiAgICAvLyBXZSBjYW4gaGFuZGxlIG1lc3NhZ2VzIGFuZCBFcnJvciBvYmplY3RzIGRpcmVjdGx5LlxuICAgIGlmICh0eXBlb2YgZXJyb3IgPT09ICdzdHJpbmcnIHx8IGlzRXJyb3JPckVycm9yTGlrZU9iamVjdChlcnJvcikpIHtcbiAgICAgIHJldHVybiBlcnJvcjtcbiAgICB9XG5cbiAgICAvLyBOb3RoaW5nIHdhcyBleHRyYWN0ZWQsIGZhbGxiYWNrIHRvIGRlZmF1bHQgZXJyb3IgbWVzc2FnZS5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vKipcbiAqIEZhY3RvcnkgZnVuY3Rpb24gdGhhdCBjcmVhdGVzIGFuIGluc3RhbmNlIG9mIGEgcHJlY29uZmlndXJlZCBFcnJvckhhbmRsZXIgcHJvdmlkZXIuXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZUVycm9ySGFuZGxlcihjb25maWc/OiBFcnJvckhhbmRsZXJPcHRpb25zKTogU2VudHJ5RXJyb3JIYW5kbGVyIHtcbiAgcmV0dXJuIG5ldyBTZW50cnlFcnJvckhhbmRsZXIoY29uZmlnKTtcbn1cblxuZXhwb3J0IHsgY3JlYXRlRXJyb3JIYW5kbGVyLCBTZW50cnlFcnJvckhhbmRsZXIgfTtcbiJdfQ==