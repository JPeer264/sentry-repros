import type { AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import { ElementRef } from '@angular/core';
import type { ActivatedRouteSnapshot, Event } from '@angular/router';
import { Router } from '@angular/router';
import { browserTracingIntegration as originalBrowserTracingIntegration } from '@sentry/browser';
import type { Integration, Span } from '@sentry/core';
import type { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * A custom browser tracing integration for Angular.
 *
 * Use this integration in combination with `TraceService`
 */
export declare function browserTracingIntegration(options?: Parameters<typeof originalBrowserTracingIntegration>[0]): Integration;
/**
 * This function is extracted to make unit testing easier.
 */
export declare function _updateSpanAttributesForParametrizedUrl(route: string, url: string, span?: Span): void;
/**
 * Angular's Service responsible for hooking into Angular Router and tracking current navigation process.
 * Creates a new transaction for every route change and measures a duration of routing process.
 */
export declare class TraceService implements OnDestroy {
    private readonly _router;
    navStart$: Observable<Event>;
    resEnd$: Observable<Event>;
    navEnd$: Observable<Event>;
    private _routingSpan;
    private _subscription;
    /**
     * @see _isPageloadOngoing()
     */
    private _pageloadOngoing;
    constructor(_router: Router);
    /**
     * This is used to prevent memory leaks when the root view is created and destroyed multiple times,
     * since `subscribe` callbacks capture `this` and prevent many resources from being GC'd.
     */
    ngOnDestroy(): void;
    /**
     * We only _avoid_ creating a navigation root span in one case:
     *
     * There is an ongoing pageload span AND the router didn't yet emit the first navigation start event
     *
     * The first navigation start event will create the child routing span
     * and update the pageload root span name on ResolveEnd.
     *
     * There's an edge case we need to avoid here: If the router fires the first navigation start event
     * _after_ the pageload root span finished. This is why we check for the pageload root span.
     * Possible real-world scenario: Angular application and/or router is bootstrapped after the pageload
     * idle root span finished
     *
     * The overall rationale is:
     * - if we already avoided creating a navigation root span once, we don't avoid it again
     *   (i.e. set `_pageloadOngoing` to `false`)
     * - if `_pageloadOngoing` is already `false`, create a navigation root span
     * - if there's no active/pageload root span, create a navigation root span
     * - only if there's an ongoing pageload root span AND `_pageloadOngoing` is still `true,
     *   don't create a navigation root span
     */
    private _isPageloadOngoing;
    static ɵfac: i0.ɵɵFactoryDeclaration<TraceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TraceService>;
}
/**
 * Captures the initialization lifecycle of the component this directive is applied to.
 * Specifically, this directive measures the time between `ngOnInit` and `ngAfterViewInit`
 * of the component.
 *
 * Falls back to the component's selector if no name is provided.
 *
 * @example
 * ```html
 * <app-my-component trace="myComponent"></app-my-component>
 * ```
 */
export declare class TraceDirective implements OnInit, AfterViewInit {
    private readonly _host;
    componentName?: string;
    private _tracingSpan?;
    constructor(_host: ElementRef<HTMLElement>);
    /**
     * Implementation of OnInit lifecycle method
     * @inheritdoc
     */
    ngOnInit(): void;
    /**
     * Implementation of AfterViewInit lifecycle method
     * @inheritdoc
     */
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TraceDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TraceDirective, "[trace]", never, { "componentName": "trace"; }, {}, never, never, false>;
}
/**
 * A module serves as a single compilation unit for the `TraceDirective` and can be re-used by any other module.
 */
export declare class TraceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TraceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TraceModule, [typeof TraceDirective], never, [typeof TraceDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TraceModule>;
}
interface TraceClassOptions {
    /**
     * Name of the class
     */
    name?: string;
}
/**
 * Decorator function that can be used to capture initialization lifecycle of the whole component.
 */
export declare function TraceClass(options?: TraceClassOptions): ClassDecorator;
interface TraceMethodOptions {
    /**
     * Name of the method (is added to the tracing span)
     */
    name?: string;
}
/**
 * Decorator function that can be used to capture a single lifecycle methods of the component.
 */
export declare function TraceMethod(options?: TraceMethodOptions): MethodDecorator;
/**
 * Takes the parameterized route from a given ActivatedRouteSnapshot and concatenates the snapshot's
 * child route with its parent to produce the complete parameterized URL of the activated route.
 * This happens recursively until the last child (i.e. the end of the URL) is reached.
 *
 * @param route the ActivatedRouteSnapshot of which its path and its child's path is concatenated
 *
 * @returns the concatenated parameterized route string
 */
export declare function getParameterizedRouteFromSnapshot(route?: ActivatedRouteSnapshot | null): string;
export {};
