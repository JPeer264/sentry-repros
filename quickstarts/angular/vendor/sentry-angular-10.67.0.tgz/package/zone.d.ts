/**
 * The function that does the same job as `NgZone.runOutsideAngular`.
 *
 * ⚠️ Note: All of the Sentry functionality called from inside the Angular
 * execution context must be wrapped in this function. Angular's rendering
 * relies on asynchronous tasks being scheduled within its execution context.
 * Since Sentry schedules tasks that do not interact with Angular's rendering,
 * it may prevent Angular from functioning reliably. Consequently, it may disrupt
 * processes such as server-side rendering or client-side hydration.
 */
export declare function runOutsideAngular<T>(callback: () => T): T;
