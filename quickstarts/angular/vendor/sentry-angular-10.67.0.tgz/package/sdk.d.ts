import type { BrowserOptions } from '@sentry/browser';
import type { Client, Integration } from '@sentry/core';
/**
 * Get the default integrations for the Angular SDK.
 */
export declare function getDefaultIntegrations(_options?: BrowserOptions): Integration[];
/**
 * Inits the Angular SDK
 */
export declare function init(options: BrowserOptions): Client | undefined;
