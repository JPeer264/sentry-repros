import type { ErrorHandler as AngularErrorHandler, OnDestroy } from '@angular/core';
import type { ReportDialogOptions } from '@sentry/browser';
import * as i0 from "@angular/core";
/**
 * Options used to configure the behavior of the Angular ErrorHandler.
 */
export interface ErrorHandlerOptions {
    logErrors?: boolean;
    showDialog?: boolean;
    dialogOptions?: ReportDialogOptions;
    /**
     * Custom implementation of error extraction from the raw value captured by the Angular.
     * @param error Value captured by Angular's ErrorHandler provider
     * @param defaultExtractor Default implementation that can be used as the fallback in case of custom implementation
     */
    extractor?(error: unknown, defaultExtractor: (error: unknown) => unknown): unknown;
}
/**
 * Implementation of Angular's ErrorHandler provider that can be used as a drop-in replacement for the stock one.
 */
declare class SentryErrorHandler implements AngularErrorHandler, OnDestroy {
    protected readonly _options: ErrorHandlerOptions;
    /** The cleanup function is executed when the injector is destroyed. */
    private _removeAfterSendEventListener?;
    constructor(options?: ErrorHandlerOptions);
    /**
     * Method executed when the injector is destroyed.
     */
    ngOnDestroy(): void;
    /**
     * Method called for every value captured through the ErrorHandler
     */
    handleError(error: unknown): void;
    /**
     * Used to pull a desired value that will be used to capture an event out of the raw value captured by ErrorHandler.
     */
    protected _extractError(error: unknown): unknown;
    /**
     * Default implementation of error extraction that handles default error wrapping, HTTP responses, ErrorEvent and few other known cases.
     */
    protected _defaultExtractor(errorCandidate: unknown): unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<SentryErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SentryErrorHandler>;
}
/**
 * Factory function that creates an instance of a preconfigured ErrorHandler provider.
 */
declare function createErrorHandler(config?: ErrorHandlerOptions): SentryErrorHandler;
export { createErrorHandler, SentryErrorHandler };
