export declare var onCreateWebpackConfig: ({ getConfig, actions }: {
    actions: any;
    getConfig: any;
}, options: any) => void;
