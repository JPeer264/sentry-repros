<p align="center">
  <a href="https://sentry.io/?utm_source=github&utm_medium=logo" target="_blank">
    <img src="https://sentry-brand.storage.googleapis.com/sentry-wordmark-dark-280x84.png" alt="Sentry" width="280" height="84">
  </a>
</p>

# Sentry Integration for Feedback

> [!NOTE]
> This package is an internal library published for use by Sentry-owned JavaScript SDK packages. It is not part of the
> public API contract and may change in any release. Do not rely on SemVer compatibility if you depend on it directly.

This SDK is **considered experimental and in a beta state**. It may experience breaking changes, and may be discontinued
at any time. Please reach out on [GitHub](https://github.com/getsentry/sentry-javascript/issues/new/choose) if you have
any feedback/concerns.

To view Feedback in Sentry, your
[Sentry organization must be an early adopter](https://docs.sentry.io/product/accounts/early-adopter-features/).

## Installation

Please read the [official integration documentation](https://docs.sentry.io/platforms/javascript/user-feedback/) for
installation instructions.

## Configuration

The Feedback integration is highly customizable, please read the
[official integration documentation](https://docs.sentry.io/platforms/javascript/user-feedback/configuration/) for the
most up-to-date configuration options.
