/**
 * @sentry/ember - Official Sentry SDK for Ember.js
 *
 * @see {@link https://docs.sentry.io/platforms/javascript/guides/ember/ Sentry Ember Documentation}
 */
export * from '@sentry/browser';
export { init } from './init.ts';
export { instrumentRoutePerformance } from './utils/instrumentRoutePerformance.ts';
export { browserTracingIntegration, instrumentAppInstancePerformance } from './utils/browserTracingIntegration.ts';
//# sourceMappingURL=index.d.ts.map