import { browserTracingIntegration as originalBrowserTracingIntegration } from '@sentry/browser';
import type { Integration } from '@sentry/core';
import type ApplicationInstance from '@ember/application/instance';
type EmberBrowserTracingIntegrationOptions = Parameters<typeof originalBrowserTracingIntegration>[0] & {
    appInstance: ApplicationInstance;
    disableRunloopPerformance?: boolean;
    minimumRunloopQueueDuration?: number;
    disableInstrumentComponents?: boolean;
    minimumComponentRenderDuration?: number;
    enableComponentDefinitions?: boolean;
    disableInitialLoadInstrumentation?: boolean;
};
export declare function browserTracingIntegration(options: EmberBrowserTracingIntegrationOptions): Integration;
/**
 * Utility to simplify adding the browser tracing integration to an app instance.
 */
export declare function instrumentAppInstancePerformance(appInstance: ApplicationInstance, options?: Partial<Parameters<typeof browserTracingIntegration>[0]>): void;
export {};
//# sourceMappingURL=browserTracingIntegration.d.ts.map