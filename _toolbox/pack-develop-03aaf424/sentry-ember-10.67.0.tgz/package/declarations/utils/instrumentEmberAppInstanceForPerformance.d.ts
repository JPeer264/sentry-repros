import type ApplicationInstance from '@ember/application/instance';
import type RouterService from '@ember/routing/router-service';
import type { startBrowserTracingNavigationSpan as startBrowserTracingNavigationSpanType, startBrowserTracingPageLoadSpan as startBrowserTracingPageLoadSpanType } from '@sentry/browser';
import { type Client } from '@sentry/core';
interface EmberRouterMain {
    location: {
        formatURL?: (url: string) => string;
        getURL?: () => string;
        implementation?: string;
        rootURL: string;
    };
}
export declare function instrumentEmberAppInstanceForPerformance(client: Client, appInstance: ApplicationInstance, config: {
    disableRunloopPerformance?: boolean;
    instrumentPageLoad?: boolean;
    instrumentNavigation?: boolean;
}, startBrowserTracingPageLoadSpan: typeof startBrowserTracingPageLoadSpanType, startBrowserTracingNavigationSpan: typeof startBrowserTracingNavigationSpanType): void;
export declare function _recognizeURL(routerService: RouterService, url: string): ReturnType<RouterService['recognize']> | undefined;
export declare function _getLocationURL(location: EmberRouterMain['location']): string;
export {};
//# sourceMappingURL=instrumentEmberAppInstanceForPerformance.d.ts.map