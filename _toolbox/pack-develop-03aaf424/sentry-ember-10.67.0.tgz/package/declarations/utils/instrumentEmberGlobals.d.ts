type Payload = {
    containerKey: string;
    initialRender: true;
    object: string;
};
type RenderEntry = {
    now: number;
};
export type RenderEntries = WeakMap<Payload, RenderEntry>;
/** This is global, so should only be run once in tests! */
export declare function instrumentGlobalsForPerformance(config: {
    disableRunloopPerformance?: boolean;
    minimumRunloopQueueDuration?: number;
    disableInstrumentComponents?: boolean;
    minimumComponentRenderDuration?: number;
    enableComponentDefinitions?: boolean;
    disableInitialLoadInstrumentation?: boolean;
}): void;
export declare function _processComponentRenderBefore(payload: Payload, beforeEntries: RenderEntries): void;
export declare function _processComponentRenderAfter(payload: Payload, beforeEntries: RenderEntries, op: string, minComponentDuration: number): void;
export {};
//# sourceMappingURL=instrumentEmberGlobals.d.ts.map