import type Route from '@ember/routing/route';
type RouteConstructor = new (...args: ConstructorParameters<typeof Route>) => Route;
/**
 * Enables monitoring the performance of an Ember app.
 *
 * This wraps the route's lifecycle hooks (beforeModel, model, afterModel, setupController)
 * with Sentry spans to track their performance.
 *
 * @param BaseRoute - The Route class to instrument
 * @returns The instrumented Route class
 *
 * @example
 * ```ts
 * import Route from '@ember/routing/route';
 * import { instrumentRoutePerformance } from '@sentry/ember';
 *
 * class ApplicationRoute extends Route {
 *   async model() {
 *     return this.store.findAll('post');
 *   }
 * }
 *
 * export default instrumentRoutePerformance(ApplicationRoute);
 * ```
 */
export declare function instrumentRoutePerformance<T extends RouteConstructor>(BaseRoute: T): T;
export {};
//# sourceMappingURL=instrumentRoutePerformance.d.ts.map