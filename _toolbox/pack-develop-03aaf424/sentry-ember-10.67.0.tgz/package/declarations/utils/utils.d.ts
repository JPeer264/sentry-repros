interface ExtendedBackburner {
    on(eventName: string, callback: (...args: unknown[]) => void): void;
    off(eventName: string, callback: (...args: unknown[]) => void): void;
}
export declare function getBackburner(): Pick<ExtendedBackburner, 'on' | 'off'>;
export {};
//# sourceMappingURL=utils.d.ts.map